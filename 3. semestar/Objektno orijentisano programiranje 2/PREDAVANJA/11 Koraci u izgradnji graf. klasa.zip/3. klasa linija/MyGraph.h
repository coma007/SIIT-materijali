#ifndef MY_GRAPH_GUARD
#define MY_GRAPH_GUARD

#include "Point.h"
#include "std_lib_facilities.h"


namespace My_graph_lib
{

class Line {
public:
	Line(Point x, Point y) : a(x), b(y) {}

	Point getA() const { return a; }
	Point getB() const { return b; }

private:
	Point a;
	Point b;
};

} // of namespace Graph_lib

#endif
