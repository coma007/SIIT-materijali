
#include "MyWindow.h"

#include <FL/fl_draw.H>

//------------------------------------------------------------------------------

namespace My_graph_lib {

My_window::My_window(int ww, int hh, const string& title)
	: Fl_Window(ww, hh, title.c_str()), w(ww), h(hh)
{
	init();
}

//------------------------------------------------------------------------------

My_window::My_window(Point xy, int ww, int hh, const string& title)
	: Fl_Window(xy.x, xy.y, ww, hh, title.c_str()), w(ww), h(hh)
{
	init();
}

//------------------------------------------------------------------------------

void My_window::draw()
{
	Fl_Window::draw();

	Fl_Color oldc = fl_color();
	fl_color(FL_DARK3);

	fl_line(100, 100, 400, 400);

	//fl_color(oldc);
}

//------------------------------------------------------------------------------

void My_window::init()
{
	resizable(this); // part of Fl_Window
	show(); // part of Fl_Window
}

//------------------------------------------------------------------------------

int gui_main()
{
	return Fl::run();
}

//------------------------------------------------------------------------------

}; // of namespace My_graph_lib
