﻿#include "MyWindow.h"

int main(int argc, char** argv)
{
	using namespace My_graph_lib;

	Point tl(100, 200);

	My_window win(tl, 600, 400, "Canvas");

	gui_main();	// пренеси контролу графичком подсистему

	return 0;
}
