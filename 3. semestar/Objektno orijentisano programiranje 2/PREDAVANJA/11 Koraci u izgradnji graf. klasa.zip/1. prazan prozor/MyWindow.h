#ifndef MY_WINDOW_GUARD
#define MY_WINDOW_GUARD

#include <FL/Fl.H>
#include <FL/Fl_Window.H>

#include <string>

#include "Point.h"

using std::string;

namespace My_graph_lib
{

class My_window : public Fl_Window {
public:
	// let the system pick the location:
	My_window(int w, int h, const string& title);
	// top left corner in xy
	My_window(Point xy, int w, int h, const string& title);

	virtual ~My_window() { }

	int x_max() const { return w; }
	int y_max() const { return h; }

	void resize(int ww, int hh) { w = ww; h = hh; size(ww, hh); /*size is part of Fl_Window*/ }

	void set_label(const string& s) { copy_label(s.c_str()); /*copy_label is part of Fl_Window*/ }

private:
	int w;
	int h;

	void init();
};

//------------------------------------------------------------------------------

int gui_main(); // invoke GUI library's main event loop
inline int x_max() { return Fl::w(); } // width of screen in pixels
inline int y_max() { return Fl::h(); } // height of screen in pixels

} // of namespace My_graph_lib

#endif // MY_WINDOW_GUARD
