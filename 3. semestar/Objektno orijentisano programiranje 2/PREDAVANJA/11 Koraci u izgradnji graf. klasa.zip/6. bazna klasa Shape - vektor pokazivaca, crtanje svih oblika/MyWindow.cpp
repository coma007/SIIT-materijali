#include "MyWindow.h"

#include <FL/fl_draw.H>

//------------------------------------------------------------------------------

namespace My_graph_lib {

My_window::My_window(int ww, int hh, const string& title)
	: Fl_Window(ww, hh, title.c_str()), w(ww), h(hh)
{
	init();
}

//------------------------------------------------------------------------------

My_window::My_window(Point xy, int ww, int hh, const string& title)
	: Fl_Window(xy.x, xy.y, ww, hh, title.c_str()), w(ww), h(hh)
{
	init();
}

//------------------------------------------------------------------------------

void My_window::draw()
{
	Fl_Window::draw();

	Fl_Color oldc = fl_color();
	fl_color(FL_DARK3);

	for (Shape* s : shapes) {
		switch (s->kind)
		{
		case 1:
			{
				Line* l = static_cast<Line*>(s);
				fl_line(l->getA().x, l->getA().y, l->getB().x, l->getB().y);
			}
			break;
		case 2:
			{
				Rectangle* r = static_cast<Rectangle*>(s);
				fl_rect(r->getX().x, r->getX().y, r->width(), r->height());
			}
			break;
		case 3:
			{
				OpenPolyline* pl = static_cast<OpenPolyline*>(s);
				for (unsigned int j = 1; j < pl->points.size(); ++j) {
					fl_line(pl->points[j - 1].x, pl->points[j - 1].y, pl->points[j].x, pl->points[j].y);
				}
			}
			break;
		}
	}

	//fl_color(oldc);
}

//------------------------------------------------------------------------------

void My_window::init()
{
	resizable(this); // part of Fl_Window
	show(); // part of Fl_Window
}

//------------------------------------------------------------------------------

int gui_main()
{
	return Fl::run();
}

//------------------------------------------------------------------------------

}; // of namespace My_graph_lib
