public class Matrix<T> {
	protected Object m_elem[];
	protected int m_sz;
	protected int m_d1;
	protected int m_d2;
	
	public Matrix(int d1, int d2) {
		m_elem = new Object[d1 * d2];
		m_sz = d1 * d2;
		m_d1 = d1;
		m_d2 = d2;
	}

	public T get(int i, int j) { return (T)m_elem[i * m_d1 + j]; }
	public void set(int i, int j, Object e) { m_elem[i * m_d1 + j] = e; }

	public int d1() { return m_d1; }
	public int d2() { return m_d2; }

	public static <T> Matrix<T> add(Matrix<T> x, Matrix<T> y){
		
		Matrix<T> z = new Matrix<T>(x.d1(), x.d2());
		for (int i = 0; i < x.m_sz; ++i) {
			z.m_elem[i] = (Integer)x.m_elem[i] + (Integer)y.m_elem[i];
		}
		return z;
	}
}