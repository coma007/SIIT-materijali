/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.concurrent.TimeUnit;

public class Main
{
	public static void fillMatrix(Matrix<Integer> m) {
		int v = 1001;
		for (int i = 0; i < m.d1(); ++i) {
			for (int j = 0; j < m.d2(); ++j) {
				m.set(i, j, (v++));
				if (v == 1010) v = 1000;
			}
		}
	}

	public static void main(String[] args) {
		Matrix<Integer> a = new Matrix<Integer>(1000, 1000);
		fillMatrix(a);
		Matrix<Integer> b = new Matrix<Integer>(1000, 1000);
		fillMatrix(b);
		
		long startT = System.nanoTime();
		
		Matrix<Integer> c = Matrix.add(a, b);
		
		long endT = System.nanoTime();
		

		//System.out.println(c.get(1, 1));
		//System.out.println(a.get(4, 1));
		//System.out.println(b.get(1, 4));
		long res = endT - startT;
		
		System.out.println(res);
		System.out.println((double)TimeUnit.NANOSECONDS.toMillis(res) * 0.001);
	}
}
