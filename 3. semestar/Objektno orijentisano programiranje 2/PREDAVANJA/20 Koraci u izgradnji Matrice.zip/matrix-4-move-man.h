﻿#ifndef __MATRIX_H__
#define __MATRIX_H__

/*
Ово је верзија Matrix класе која је направљена генерички, са ослањањем на Це++ шаблоне (темплејте).
Помоћу поља m_move покушава се избећи део непотребног заузимања меморије и копирања садржаја матрице,
видљивог, у овом примеру, на употреби оператора сабирања.
Овакво решење има низ озбиљних недостатака, али служи само као додатна илустрација самог проблема,
а и смера у којем лежи његово потпуније ручно решење. Тек механизам мув конструкора и мув доделе,
уведен у Це++11, даје потпуно и елегантно решење.
*/


#include <cassert>
#include <iostream>
#include "std_lib_facilities.h"

namespace MyMatrix
{

template<class T = int>
class Matrix;

template<class T> std::istream& operator >> (std::istream& is, Matrix<T>& m);

template<class T>
class Matrix
{
protected:
	T* m_elem;
	const int m_sz;
	const int m_d1;
	const int m_d2;

	bool m_move = false;

public:
	Matrix(int d1, int d2) : m_elem(new T[d1*d2]()), m_sz(d1*d2), m_d1(d1), m_d2(d2) {
		// Садржај матрице је неиницијализован
	}

	Matrix(int d1, int d2, std::istream& is)
		: m_elem(new T[d1*d2]()), m_sz(d1*d2), m_d1(d1), m_d2(d2) {
		is >> *this;
	}

	Matrix(const Matrix& X) : m_elem(nullptr), m_sz(X.m_sz), m_d1(X.m_d1), m_d2(X.m_d2) {
		if (X.m_move) {
			m_elem = X.m_elem;
		}
		else {
			m_elem = new T[m_sz]();
			T* pi = X.m_elem;
			T* po = m_elem;
			for (int i = 0; i < X.m_sz; ++i)
				*po++ = *pi++;
		}
	}

	Matrix& operator=(const Matrix& X) {
		if (m_elem == X.m_elem) return *this;

		if (m_d1 != X.m_d1 || m_d2 != X.m_d2) error("lose dimenzije");

		if (X.m_move) {
			delete[] m_elem;
			m_elem = X.m_elem;
		}
		else {
			// пошто су дименизије исте, онда је и m_sz исто, па нема потребе за новим заузимањем меморије

			T* pi = X.m_elem;
			T* po = m_elem;
			for (int i = 0; i < m_sz; ++i)
				*po++ = *pi++;
		}

		return *this;
	}

	~Matrix() {
		if (!m_move)
			delete[] m_elem;
		// у случају да је m_move true, власништво над меморијом ће се пренети на други објекат
		// тако да је не треба брисати
	}

	T& operator()(int i, int j) {
		return m_elem[i * m_d1 + j];
	}

	const T& operator()(int i, int j) const {
		return m_elem[i * m_d1 + j];
	}

	T* data() { return m_elem; }
	const T* data() const { return m_elem; }

	int d1() const { return m_d1; }
	int d2() const { return m_d2; }

	void setMove() { m_move = true; }
};


template<class T> Matrix<T> operator+(const Matrix<T>& A, const Matrix<T>& B)
{
	if (A.d1() != B.d1() || A.d2() != B.d2()) error("Matrix dimension missmatch.");
	int n = A.d1();
	int m = A.d2();

	Matrix<T> C(n, m);

	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			C(i, j) = A(i, j) + B(i, j);
		}
	}

	C.setMove();
	return C;
}


template<class T> std::istream& operator >> (std::istream& is, Matrix<T>& m)
{
	char ch;
	is >> ch;

	if (ch != '{') error("nedostaje '{'");

	for (int i = 0; i < m.d1(); ++i) {
		for (int j = 0; j < m.d2(); ++j) {
			is >> m(i, j);
		}
	}

	is >> ch;

	if (ch != '}') error("nedostaje '}'");

	return is;
}


template<class T> std::ostream& operator << (std::ostream& os, const Matrix<T>& m)
{
	os << "{\n";

	for (int i = 0; i < m.d1(); ++i) {
		for (int j = 0; j < m.d2(); ++j) {
			os << m(i, j) << " ";
		}
		os << '\n';
	}

	os << "}\n";

	return os;
}

}

#endif
