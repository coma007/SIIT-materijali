﻿
#include "matrix-2-temp.h"

#include <fstream>
#include <chrono>


using namespace MyMatrix;
using namespace std;

int g;

void foo(Matrix<>& x)
{
	g = x(5, 17); // служи само да спречи одстрањивање кода у main() као непотребног
}


void main()
{
	Matrix<> X(1000, 1000);
	Matrix<int> Y(1000, 1000); // декларација са празним <> је иста као и са <int> због подразумеване вредности параметра
	ifstream fileX("inputXMax.txt");
	ifstream fileY("inputYMax.txt");

	fileX >> X;
	fileY >> Y;

	auto t1 = chrono::high_resolution_clock::now();
	//std::cout << X + Y;
	foo(X + Y); // неопходне су функција operator+ и конструктор копије: Matrix(const Matrix& X)
	auto t2 = chrono::high_resolution_clock::now();
	chrono::duration<double> time_span = chrono::duration_cast<chrono::duration<double>>(t2 - t1);
	cout << "It took me " << time_span.count() << " seconds.";

	return;
}
