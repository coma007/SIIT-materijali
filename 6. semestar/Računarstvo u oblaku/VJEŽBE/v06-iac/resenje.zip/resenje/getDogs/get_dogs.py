import json
import os
import boto3

# Extract environment variable
table_name = os.environ['TABLE_NAME']
dynamodb = boto3.resource('dynamodb')

def get_all(event, context):
    # Get table instance connection
    table = dynamodb.Table(table_name)
    # Get all items from table
    response = table.scan()
    # Create response
    body = {
        'data': response['Items']
    }
    return { 'statusCode': 200, 'body': json.dumps(body, default=str) }
