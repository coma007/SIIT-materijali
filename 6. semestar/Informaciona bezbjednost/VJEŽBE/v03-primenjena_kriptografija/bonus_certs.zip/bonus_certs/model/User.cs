
namespace bonus_certs.model
{
    public class User {
        public string Username { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
    }
}