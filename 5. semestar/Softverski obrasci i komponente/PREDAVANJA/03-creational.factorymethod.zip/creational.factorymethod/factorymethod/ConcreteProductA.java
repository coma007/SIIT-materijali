package factorymethod;

public class ConcreteProductA implements Product {

	@Override
	public String who() {
		return "Product A";
	}

}
