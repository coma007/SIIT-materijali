package factorymethod;

public class ConcreteProductB implements Product {

	@Override
	public String who() {
		return "Product B";
	}

}
