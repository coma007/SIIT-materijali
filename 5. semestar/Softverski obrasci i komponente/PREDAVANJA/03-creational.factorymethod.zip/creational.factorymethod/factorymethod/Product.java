package factorymethod;

public interface Product {

	String who();

}
