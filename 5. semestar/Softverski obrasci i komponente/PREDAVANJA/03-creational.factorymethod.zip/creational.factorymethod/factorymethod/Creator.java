package factorymethod;

public interface Creator {

	Product factoryMethod();

}
