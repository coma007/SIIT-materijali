package composite.shapes;

public interface IShape {
	public void draw();
}
