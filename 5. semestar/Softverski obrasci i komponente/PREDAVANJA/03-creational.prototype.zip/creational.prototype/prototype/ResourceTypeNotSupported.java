package prototype;

@SuppressWarnings("serial")
public class ResourceTypeNotSupported extends Exception {


}
