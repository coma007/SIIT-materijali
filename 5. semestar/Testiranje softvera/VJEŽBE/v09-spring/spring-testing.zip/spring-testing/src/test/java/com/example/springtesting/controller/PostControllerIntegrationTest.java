package com.example.springtesting.controller;

import com.example.springtesting.dto.CommentsDto;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class PostControllerIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    @DisplayName("Should List All Comments By Post When making GET request to endpoint - /api/comments/by-post/{postId}")
    public void shouldRetriveAllComment() {
        ResponseEntity<List<CommentsDto>> responseEntity = restTemplate.exchange("/api/comments/by-post/1",
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<CommentsDto>>() {
                });

        List<CommentsDto> comments = responseEntity.getBody();

        for (CommentsDto c:comments) {
            System.out.println(c.getText());
            System.out.println(c.getUserName());
        }

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(2, comments.size());
    }
}