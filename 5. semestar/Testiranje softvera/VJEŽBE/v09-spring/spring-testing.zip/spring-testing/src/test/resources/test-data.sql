INSERT INTO user(`user_id`,`created`,`email`,`enabled`,`password`,`username`)
VALUES (null ,null ,'test@email.com',true,'s3cr3t','testuser_sql');

INSERT INTO subreddit(`id`,`created_date`,`description`,`name`,`user_user_id`)
VALUES (1 ,'2022-11-11' ,'TEST','Testing Course',1);

INSERT INTO post(`post_id`,`created_date`,`description`,`post_name`, `id`, `user_id`)
VALUES (1 ,'2022-11-11' ,'Post from testing DB','Spring Boot Testing',1, 2);

INSERT INTO comment(`id`,`created_date`,`text`,`post_id`, `user_id`)
VALUES (1 ,'2022-11-11' ,'Comment from testing DB',1, 2);