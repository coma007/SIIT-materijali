package com.example.springtesting.service;

import com.example.springtesting.dto.CommentsDto;
import com.example.springtesting.exceptions.SpringRedditException;
import com.example.springtesting.mapper.CommentMapper;
import com.example.springtesting.model.Comment;
import com.example.springtesting.model.Post;
import com.example.springtesting.model.User;
import com.example.springtesting.repository.CommentRepository;
import com.example.springtesting.repository.PostRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.time.Instant;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@SpringBootTest
public class CommentServiceTest {

    @Autowired
    private CommentService commentService;

    @MockBean
    private PostRepository postRepository;

    @MockBean
    private CommentRepository commentRepository;

    @MockBean
    private AuthService authService;

    @MockBean
    private CommentMapper commentMapper;

    @Captor
    private ArgumentCaptor<Comment> commentArgumentCaptor;

    @Test
    @DisplayName("Test Should Save New Comment On A Post ")
    public void shouldSaveCommentOnPost() {
        CommentsDto commentsDTO = new CommentsDto(null, 123l, "text", "test_user", null);
        Post post = new Post(123L, "First Post", Instant.now(), "Test", null, null);
        User currentUser = new User(123L, "test user", "secret password", "user@email.com", Instant.now(), true);

        Comment expectedComment = new Comment(1l, "text", null, post, currentUser);

        Mockito.when(postRepository.findById(123L)).thenReturn(Optional.of(post));
        Mockito.when(commentMapper.map(eq(commentsDTO), Mockito.any(Post.class), Mockito.any(User.class))).thenReturn(expectedComment);

        commentService.save(commentsDTO);

        verify(commentRepository, times(1)).save(commentArgumentCaptor.capture());
    }

    @Test
    @DisplayName("Test Should Pass When Comment do not Contains Swear Words")
    public void shouldNotContainSwearWordsInsideComment() throws SpringRedditException {
        assertFalse(commentService.containsSwearWords("This is a comment"));
    }

    @Test
    @DisplayName("Should Throw Exception when Exception Contains Swear Words")
    public void shouldFailWhenCommentContainsSwearWords() {
        SpringRedditException exception = assertThrows(SpringRedditException.class, () -> commentService.containsSwearWords("This is a shitty comment"));
        assertEquals("Comments contains unacceptable language", exception.getMessage());
    }
}