package com.example.springtesting.service;

import com.example.springtesting.dto.PostRequest;
import com.example.springtesting.dto.PostResponse;
import com.example.springtesting.exceptions.PostNotFoundException;
import com.example.springtesting.mapper.PostMapper;
import com.example.springtesting.model.Post;
import com.example.springtesting.model.Subreddit;
import com.example.springtesting.model.User;
import com.example.springtesting.repository.PostRepository;
import com.example.springtesting.repository.SubredditRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Optional;

import static java.util.Collections.emptyList;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PostServiceTest {

    @Mock
    private PostRepository postRepository;
    @Mock
    private SubredditRepository subredditRepository;
    @Mock
    private AuthService authService;
    @Mock
    private PostMapper postMapper;

    @Captor
    private ArgumentCaptor<Post> postArgumentCaptor;

    @InjectMocks
    private PostService postService;

    @Test
    @DisplayName("Should Retrieve Post by Id")
    public void shouldFindPostById() {
        Post post = new Post(123L, "First Post", Instant.now(), "Test", null, null);

        PostResponse expectedPostResponse = new PostResponse(123L, "First Post", "http://url.site", "Test",
                "Test User", "Test Subredit", 0);

        Mockito.when(postRepository.findById(123L)).thenReturn(Optional.of(post));
        Mockito.when(postMapper.mapToDto(Mockito.any(Post.class))).thenReturn(expectedPostResponse);

        PostResponse actualPostResponse = postService.getPost(123L);

        Assertions.assertThat(actualPostResponse.getId()).isEqualTo(expectedPostResponse.getId());
        Assertions.assertThat(actualPostResponse.getPostName()).isEqualTo(expectedPostResponse.getPostName());
    }

    @Test
    @DisplayName("Should Throw Exception if Post ID doesn't exist")
    public void shouldNotFoundPostThatDoesntExist() {

        Mockito.when(postRepository.findById(123L)).thenThrow(PostNotFoundException.class);

        assertThrows(PostNotFoundException.class, () -> postService.getPost(123L));

        verify(postRepository, times(1)).findById(123L);
        verifyNoInteractions(postMapper);
    }

    @Test
    @DisplayName("Should Save Posts")
    public void shouldSavePosts() {
        User currentUser = new User(123L, "test user", "secret password", "user@email.com", Instant.now(), true);

        Subreddit subreddit = new Subreddit(123L, "First Subreddit", "Subreddit Description", Instant.now(), emptyList(), currentUser);

        Post post = new Post(123L, "First Post", Instant.now(), "Test", null, null);

        PostRequest postRequest = new PostRequest(null, "First Subreddit", "First Post", "http://url.site", "Test");

        Mockito.when(subredditRepository.findByName("First Subreddit"))
                .thenReturn(Optional.of(subreddit));
        Mockito.when(authService.getCurrentUser())
                .thenReturn(currentUser);
        Mockito.when(postMapper.map(postRequest, subreddit, currentUser))
                .thenReturn(post);

        postService.save(postRequest);
        verify(postRepository, times(1)).save(postArgumentCaptor.capture());

        Assertions.assertThat(postArgumentCaptor.getValue().getPostId()).isEqualTo(123L);
        Assertions.assertThat(postArgumentCaptor.getValue().getPostName()).isEqualTo("First Post");
    }
}
