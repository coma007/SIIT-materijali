package com.example.springtesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
