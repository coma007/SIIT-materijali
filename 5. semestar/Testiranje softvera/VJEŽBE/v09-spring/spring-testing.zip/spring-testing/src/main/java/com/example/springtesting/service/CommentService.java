package com.example.springtesting.service;

import com.example.springtesting.dto.CommentsDto;
import com.example.springtesting.exceptions.PostNotFoundException;
import com.example.springtesting.exceptions.SpringRedditException;
import com.example.springtesting.exceptions.UsernameNotFoundException;
import com.example.springtesting.mapper.CommentMapper;
import com.example.springtesting.model.Comment;
import com.example.springtesting.model.Post;
import com.example.springtesting.model.User;
import com.example.springtesting.repository.CommentRepository;
import com.example.springtesting.repository.PostRepository;
import com.example.springtesting.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
public class CommentService {

    @Autowired
    private AuthService authService;

    @Autowired
    private  PostRepository postRepository;

    @Autowired
    private  UserRepository userRepository;

    @Autowired
    private  CommentRepository commentRepository;

    @Autowired
    private CommentMapper commentMapper;

    public void save(CommentsDto commentsDto) {
        Post post = postRepository.findById(commentsDto.getPostId())
                .orElseThrow(() -> new PostNotFoundException(commentsDto.getPostId().toString()));

        Comment comment = commentMapper.map(commentsDto, post, authService.getCurrentUser());
        commentRepository.save(comment);
    }


    public List<CommentsDto> getAllCommentsForPost(Long postId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new PostNotFoundException(postId.toString()));

        return commentRepository.findByPost(post)
                .stream()
                .map(commentMapper::mapToDto).collect(toList());
    }

    public List<CommentsDto> getAllCommentsForUser(String userName) {
        User user = userRepository.findByUsername(userName)
                .orElseThrow(() -> new UsernameNotFoundException(userName));

        return commentRepository.findAllByUser(user)
                .stream()
                .map(commentMapper::mapToDto)
                .collect(toList());
    }

    public boolean containsSwearWords(String comment) throws SpringRedditException {
        if (comment.contains("shit")) {
            throw new SpringRedditException("Comments contains unacceptable language");
        }

        return false;
    }
}