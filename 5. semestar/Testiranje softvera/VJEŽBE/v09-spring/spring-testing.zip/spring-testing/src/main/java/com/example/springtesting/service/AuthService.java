package com.example.springtesting.service;

import com.example.springtesting.model.User;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    public User getCurrentUser() {
        User currentUser = new User(2l, "username", "pass123", "user@gmail.com", null, true);

        return currentUser;
    }
}
