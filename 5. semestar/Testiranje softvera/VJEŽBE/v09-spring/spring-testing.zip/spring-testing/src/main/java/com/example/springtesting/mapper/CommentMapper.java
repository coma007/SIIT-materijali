package com.example.springtesting.mapper;

import com.example.springtesting.dto.CommentsDto;
import com.example.springtesting.model.Comment;
import com.example.springtesting.model.Post;
import com.example.springtesting.model.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
@Mapper(componentModel = "spring")
public interface CommentMapper {
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "text", source = "commentsDto.text")
    @Mapping(target = "createdDate", expression = "java(java.time.Instant.now())")
    @Mapping(target = "post", source = "post")
    @Mapping(target = "user", source = "user")
    public  Comment map(CommentsDto commentsDto, Post post, User user);

    @Mapping(target = "postId", source = "comment.post.postId")
    @Mapping(target = "userName", source = "comment.user.username")
    public  CommentsDto mapToDto(Comment comment);
}
