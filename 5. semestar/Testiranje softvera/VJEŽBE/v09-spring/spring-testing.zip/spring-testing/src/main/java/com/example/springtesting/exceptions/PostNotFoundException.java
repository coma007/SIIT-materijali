package com.example.springtesting.exceptions;

public class PostNotFoundException extends RuntimeException {
    public PostNotFoundException(String message) {
    }
}