INSERT INTO user(`user_id`,`created`,`email`,`enabled`,`password`,`username`)
VALUES (1 ,null ,'subreddit@email.com',true,'user123','subreddit_user');

INSERT INTO user(`user_id`,`created`,`email`,`enabled`,`password`,`username`)
VALUES (2 ,null ,'post@email.com',true,'user123','post_user');

INSERT INTO subreddit(`id`,`created_date`,`description`,`name`,`user_user_id`)
VALUES (1 ,'2022-11-11' ,'Course for app testing','Testing Course',1);

INSERT INTO post(`post_id`,`created_date`,`description`,`post_name`, `id`, `user_id`)
VALUES (1 ,'2022-11-11' ,'Post about Spring Boot Testing','Spring Boot Testing',1, 2);

INSERT INTO comment(`id`,`created_date`,`text`,`post_id`, `user_id`)
VALUES (1 ,'2022-11-11' ,'Interesting',1, 2);

INSERT INTO comment(`id`,`created_date`,`text`,`post_id`, `user_id`)
VALUES (2 ,'2022-12-11' ,'I agree',1, 1);