package com.example.springtesting.service;


import com.example.springtesting.dto.PostRequest;
import com.example.springtesting.dto.PostResponse;
import com.example.springtesting.exceptions.PostNotFoundException;
import com.example.springtesting.exceptions.SubredditNotFoundException;
import com.example.springtesting.exceptions.UsernameNotFoundException;
import com.example.springtesting.mapper.PostMapper;
import com.example.springtesting.model.Post;
import com.example.springtesting.model.Subreddit;
import com.example.springtesting.model.User;
import com.example.springtesting.repository.PostRepository;
import com.example.springtesting.repository.SubredditRepository;
import com.example.springtesting.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
@Transactional
public class PostService {

    @Autowired
    private AuthService authService;

    @Autowired
    private  PostRepository postRepository;

    @Autowired
    private  SubredditRepository subredditRepository;

    @Autowired
    private  UserRepository userRepository;

    @Autowired
    private PostMapper postMapper;

    public void save(PostRequest postRequest) {
        Subreddit subreddit = subredditRepository.findByName(postRequest.getSubredditName())
                .orElseThrow(() -> new SubredditNotFoundException(postRequest.getSubredditName()));

        postRepository.save(postMapper.map(postRequest, subreddit, authService.getCurrentUser()));
    }

    @Transactional
    public PostResponse getPost(Long id) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new PostNotFoundException(id.toString()));

        return postMapper.mapToDto(post);
    }

    @Transactional
    public List<PostResponse> getAllPosts() {
        return postRepository.findAll()
                .stream()
                .map(postMapper::mapToDto)
                .collect(toList());
    }

    @Transactional
    public List<PostResponse> getPostsBySubreddit(Long subredditId) {
        Subreddit subreddit = subredditRepository.findById(subredditId)
                .orElseThrow(() -> new SubredditNotFoundException(subredditId.toString()));

        List<Post> posts = postRepository.findAllBySubreddit(subreddit);

        return posts.stream().map(postMapper::mapToDto).collect(toList());
    }

    @Transactional
    public List<PostResponse> getPostsByUsername(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException(username));

        return postRepository.findByUser(user)
                .stream()
                .map(postMapper::mapToDto)
                .collect(toList());
    }
}