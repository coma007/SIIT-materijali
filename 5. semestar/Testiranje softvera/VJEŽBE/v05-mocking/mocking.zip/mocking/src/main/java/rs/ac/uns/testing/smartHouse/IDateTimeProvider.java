package rs.ac.uns.testing.smartHouse;

import java.util.Calendar;

public interface IDateTimeProvider {
    Calendar getTime();
}
