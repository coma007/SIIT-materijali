package rs.ac.uns.testing.user;

public interface PasswordEncoder {
    String encode(String password);
}