package rs.ac.uns.testing.user;

public interface UserRepository {
    User findById(String id);
}