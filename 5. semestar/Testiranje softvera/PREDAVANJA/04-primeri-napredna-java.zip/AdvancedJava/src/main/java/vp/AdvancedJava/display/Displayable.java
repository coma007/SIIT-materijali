package vp.AdvancedJava.display;

public interface Displayable {
	void displayData(String prefix);
}
