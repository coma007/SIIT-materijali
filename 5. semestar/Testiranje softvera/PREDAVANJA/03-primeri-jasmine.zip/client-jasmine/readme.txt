Pokretanje testova:
npm test


U konfiguracionom json fajlu mora da stoji random false, zato što jedan test menja deljeni student objekat i nije svejedno kako će ga zateći naredni testovi