describe("A suite is just a function", function() { //suite
  var a;

  it("and so is a spec", function() { //spec
    a = 1;

    expect(a+a).toBe(2);
  });
});

describe('Matchers', function() {
	it('The toBe() matcher', function() {
		var s1 = 'Marko';
		var s2 = 'Markovic';
		expect(s1 + s2).toBe('MarkoMarkovic');
		//compares values using === operator
	});

	it('The not toBe() matcher', function() {
		var s1 = 'Marko';
		var s2 = 'Markovic';
		expect(s1 + s2).not.toBe('Marko');
	});

	it('The toEqual() matcher', function() {
		var o1 = {firstName: 'Marko', lastName: 'Markovic'};
		var o2 = {firstName: 'Marko', lastName: 'Markovic'};

		expect(o1).not.toBe(o2); //objects are not the same objects
		expect(o1).toEqual(o2); //but they are equal 
		// toEqual operator does a recursive search through the objects 
		// to determine whether the values for their keys are equivalent
	});

	it('Object definition matchers', function() {
		var o1 = {firstName: 'Marko', lastName: 'Markovic'};

		expect(o1).not.toBeNull();
		expect(o1.firstName).not.toBeUndefined();
		expect(o1.phoneNumber).toBeUndefined();
	});

	it('Arithmetic matchers', function() {
		var x = 5.37;
		var y = 10.6;
		var z = 5.32;

		expect(x).toBeLessThan(y);
		expect(y).toBeGreaterThan(x);

		expect(x).toBeCloseTo(z, 1); //they differ in one decimal place
	});

	it('Array matchers', function() {
		var x = ['Marko', 'Milan', 'Petar'];
		expect(x).toContain('Milan');
	});

	it('Partial matcher',function() {
		var o1 = {firstName: 'Marko', lastName: 'Markovic'};
		expect(o1).toEqual(
			jasmine.objectContaining({lastName: 'Markovic'})
		);
	});

	it('Exception matchers', function() {
		var f = function() {
			return x + 2; // x is undefined
		};
		
		expect(f).toThrow();
	});
});

describe('Setup and tear-down', function() {
	var a;
	var b = 3;

	beforeEach(function() { //run before each 'it' (spec)
		a = 5;
	});

	afterEach(function() { //run after each 'it' (spec)
		b = 3;
	});

	it('first test', function() {
		expect(a).toBe(5);
		a++;

		expect(b).toBe(3);
		b++;
	});

	it('second test', function() {
		expect(a).toBe(5);
		a++;

		expect(b).toBe(3);
		b++;
	});
});

describe('Test doubles', function() {
	var student = {
		avgGrade: 5.0, 
		setAvgGrade: function(grade) {
			this.avgGrade = grade;
		},
		getDefaultCity: function() {
			return 'Novi Sad';
		}
	};

	it('spy object call', function() {
		spyOn(student, 'setAvgGrade'); //affects only setAvgGrade function

		student.setAvgGrade(8.34);
		student.setAvgGrade(7.56);

		//tracks each call
		expect(student.setAvgGrade).toHaveBeenCalled();
		//tracks parameters
		expect(student.setAvgGrade).toHaveBeenCalledWith(8.34);
		expect(student.setAvgGrade).toHaveBeenCalledWith(7.56);

		//spy does not call the real method
		//avgGrade has not been changed
		expect(student.avgGrade).toBe(5.0);

		//spy is reset after each spec
	});

	it('spy object calls real method', function() {		
		//a real method can be called using callThrough
		spyOn(student, 'setAvgGrade').and.callThrough();
		student.setAvgGrade(8.34);
		expect(student.setAvgGrade).toHaveBeenCalled();
		expect(student.avgGrade).toBe(8.34);
	});

	it('spy object returns hard coded value', function() {
		//spy can set fake return value
		spyOn(student, 'getDefaultCity').and.returnValue('Beograd');
		var city = student.getDefaultCity();
		expect(student.getDefaultCity).toHaveBeenCalled();
		expect(city).toBe('Beograd');
	});

	it('spy object returns fake function', function() {
		//spy can call an arbitrary fake function
		spyOn(student, 'getDefaultCity').and.callFake(function() {
			return 'unknown';
		});
		var city = student.getDefaultCity();
		expect(student.getDefaultCity).toHaveBeenCalled();
		expect(city).toBe('unknown');
	});

	it('spy calls', function() {
		spyOn(student, 'setAvgGrade'); //affects only setAvgGrade function
		
		expect(student.setAvgGrade.calls.any()).toEqual(false);

		student.setAvgGrade(8.34);
		student.setAvgGrade(7.56);
		
		expect(student.setAvgGrade.calls.any()).toEqual(true);		
		expect(student.setAvgGrade.calls.count()).toEqual(2);
	});
});

describe('Time functions', function() {
	it('simulate time passing', function() {
		var x = 1;

		jasmine.clock().install();

		//call function after 3 s (3000 ms)
		setTimeout(function() {
      		x = 5;
    	}, 3000);

		expect(x).toBe(1);

		//simulate time passing
		jasmine.clock().tick(3001); 

		expect(x).toBe(5); //timeout callback has been called

		jasmine.clock().uninstall();
	});
});

