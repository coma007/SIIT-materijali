window.Car = function() {
	this.payToll = function() {
		return 240;
	};
};

window.Truck = function() {
	this.payToll = function() {
		return 1000;
	};
};

window.tollbooth = {
	stop: function(vehicles) {
		return vehicles.length;
	},
	payToll: function(vehicles) {
		var retVal = 0;
		for (var i = 0; i < vehicles.length; i++) {
			retVal += vehicles[i].payToll();
		}
		return retVal;
	}
};