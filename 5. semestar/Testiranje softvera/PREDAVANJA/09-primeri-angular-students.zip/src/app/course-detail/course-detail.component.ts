import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { CourseService } from '../courses/course.service';
import { EnrollmentService } from '../enrollments/enrollment.service';
import { Course } from '../model/course.model';
import { Enrollment } from '../model/enrollment.model';

import {switchMap} from 'rxjs/operators';

@Component({
  selector: 'app-course-detail',
  templateUrl: './course-detail.component.html',
  styleUrls: ['./course-detail.component.css']
})
export class CourseDetailComponent implements OnInit {
  course: Course = new Course({ // if we add a new course, create an empty course
    name: '',
  });

  enrollments: Enrollment[];

  mode: string = 'ADD';

  constructor(private courseService: CourseService, private enrollmentService: EnrollmentService,
    private route: ActivatedRoute, private location: Location, private router: Router) {
    enrollmentService.RegenerateData$.subscribe(() =>
      this.getEnrollments()
    );
  }

  ngOnInit() {
    if (this.route.snapshot.params['id']) {
      this.mode = 'EDIT';
      // fetch course if we edit the existing course
      this.route.params.pipe(switchMap((params: Params) =>
          this.courseService.getCourse(+params['id'])))
        .subscribe(res => {
          this.course = res.body;
          this.getEnrollments();
        });
    }
  }

  private getEnrollments(): void {
    this.courseService.getCourseEnrollments(this.course.id).subscribe(res =>
      this.enrollments = res.body);
  }


  save(): void {
    this.mode == 'ADD' ? this.add() : this.edit();
  }

  private add(): void {
    this.courseService.addCourse(this.course)
      .subscribe(res => {
        this.courseService.announceChange();
        this.goBack();
      });
  }

  private edit(): void {
    this.courseService.editCourse(this.course)
      .subscribe(course => {
        this.courseService.announceChange();
        this.goBack();
      });
  }

  goBack(): void {
    this.location.back();
  }

  gotoAddEnrollment(): void {
    this.router.navigate(['/addEnrollment'], { queryParams: { courseId: this.course.id } });
  }

  deleteEnrollment(enrollmentId: number): void {
    this.enrollmentService.deleteEnrollment(enrollmentId).subscribe(
      () => this.getEnrollments()
    );
  }

}
