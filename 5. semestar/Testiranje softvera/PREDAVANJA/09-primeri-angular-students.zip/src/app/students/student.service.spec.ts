import { TestBed, getTestBed, inject } from '@angular/core/testing';
import {StudentService} from './student.service';
import { Student } from '../model/student.model';
import { Enrollment} from '../model/enrollment.model';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {fakeAsync, tick} from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';

describe('StudentService', () => {
  let injector;
  let studentService: StudentService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

	beforeEach(() => {

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
       providers:    [StudentService ]
    });

    injector = getTestBed();
    studentService = TestBed.inject(StudentService);
    httpClient = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
  });
  
  afterEach(() => {
    httpMock.verify();
  });
 	
 	it('should pass simple test', () => {
	    expect(true).toBe(true);
	});

	it('getStudents() should return some students',fakeAsync(() => {
    let students: Student[];
    
    const mockStudents: Student[] = [
        {
         id: 1,
         cardNumber: 'a123',
         firstName: 'Petar',
         lastName: 'Petrovic'            
        },
       {
         id: 2,
         cardNumber: 'b456',
         firstName: 'Marko',
         lastName: 'Markovic'            
       }];
    
    studentService.getStudents().subscribe(data => {
      students = data.body;        
    });
    
    const req = httpMock.expectOne('api/students');
    expect(req.request.method).toBe('GET');
    req.flush(mockStudents);

    tick();

    expect(students.length).toEqual(2, 'should contain given amount of students');
    expect(students[0].id).toEqual(1);
    expect(students[0].cardNumber).toEqual('a123');
    expect(students[0].firstName).toEqual('Petar');
    expect(students[0].lastName).toEqual('Petrovic');

    expect(students[1].id).toEqual(2);
    expect(students[1].cardNumber).toEqual('b456');
    expect(students[1].firstName).toEqual('Marko');
    expect(students[1].lastName).toEqual('Markovic');  
       
 }));

  it('getStudent() should query url and get a student', fakeAsync(() => {
    let student: Student;   
    const mockStudent: Student = 
    {
      id: 1,
      cardNumber: 'a123',
      firstName: 'Petar',
      lastName: 'Petrovic'            
    };

    studentService.getStudent(1).subscribe(res => student = res.body);

    const req = httpMock.expectOne('api/students/1');
    expect(req.request.method).toBe('GET');
    req.flush(mockStudent);

    tick();
    
    expect(student).toBeDefined();
    expect(student.id).toEqual(1);
    expect(student.cardNumber).toEqual('a123');
    expect(student.firstName).toEqual('Petar');
    expect(student.lastName).toEqual('Petrovic');

  })); 

  it('addStudent() should query url and save a student', fakeAsync(() => {
    let newStudent: Student = new Student({  // a new student doesn't have an id
      cardNumber: 'a123',
      firstName: 'Petar',
      lastName: 'Petrovic' 
    });

    const mockStudent: Student = 
    {
      id: 1,
      cardNumber: 'a123',
      firstName: 'Petar',
      lastName: 'Petrovic'            
    };

    studentService.addStudent(newStudent).subscribe(res => newStudent = res.body);
    
    const req = httpMock.expectOne('api/students');
    expect(req.request.method).toBe('POST');
    req.flush(mockStudent);

    tick();
    expect(newStudent).toBeDefined();
    expect(newStudent.id).toEqual(1);
    expect(newStudent.cardNumber).toEqual('a123');
    expect(newStudent.firstName).toEqual('Petar');
    expect(newStudent.lastName).toEqual('Petrovic');
  }));

  it('editStudent() should query url and edit a student', fakeAsync(() => {
    let student: Student = new Student({  
      id: 1,
      cardNumber: 'a123',
      firstName: 'Petar',
      lastName: 'Petrovic' 
    });

    const mockStudent: Student = 
    {
      id: 1,
      cardNumber: 'a123',
      firstName: 'Petar',
      lastName: 'Petrovic'            
    };
    
    studentService.editStudent(student).subscribe(res => student = res.body);
    
    const req = httpMock.expectOne('api/students');
    expect(req.request.method).toBe('PUT');
    req.flush(mockStudent);
    
    tick();

    expect(student).toBeDefined();
    expect(student.id).toEqual(1);
    expect(student.cardNumber).toEqual('a123');
    expect(student.firstName).toEqual('Petar');
    expect(student.lastName).toEqual('Petrovic');
  }));

   it('deleteStudent() should query url and delete a student', () => {
    studentService.deleteStudent(1).subscribe(res => { });
    
    const req = httpMock.expectOne('api/students/1');
    expect(req.request.method).toBe('DELETE');
    req.flush({});
  });

  it('getStudentEnrollments() should query url and get enrollments', fakeAsync(() => {
    let enrollments: Enrollment[];

    const mockEnrollments = [
      {
        id: 1,
        startDate: new Date('2016-1-1'),
        endDate: new Date('2017-1-1'),
        student: {
            id: 1,
            cardNumber: 'a123',
            firstName: 'Petar',
            lastName: 'Petrovic'            
        }, 
        course: {
          id: 7,
          name: 'Matematika'
        }
      },
      {
        id: 2,
        startDate: new Date('2015-1-1'),
        endDate: new Date('2016-1-1'),
        student: {
            id: 1,
            cardNumber: 'a123',
            firstName: 'Petar',
            lastName: 'Petrovic'            
        }, 
        course: {
          id: 8,
          name: 'Programiranje'
        }
      }];

    studentService.getStudentEnrollments(1).subscribe(res => enrollments = res.body);

    const req = httpMock.expectOne('api/students/1/courses');
    expect(req.request.method).toBe('GET');
    req.flush(mockEnrollments);
    
    tick();

    expect(enrollments.length).toEqual(2, 'should contain given amount of enrollments');
    expect(enrollments[0].id).toEqual(1);
    expect(enrollments[0].startDate).toEqual(new Date('2016-1-1'));
    expect(enrollments[0].endDate).toEqual(new Date('2017-1-1'));       
    expect(enrollments[0].student.id).toEqual(1);
    expect(enrollments[0].student.cardNumber).toEqual('a123');
    expect(enrollments[0].student.firstName).toEqual('Petar');
    expect(enrollments[0].student.lastName).toEqual('Petrovic');
    expect(enrollments[0].course.id).toEqual(7);
    expect(enrollments[0].course.name).toEqual('Matematika');

    expect(enrollments[1].id).toEqual(2);
    expect(enrollments[1].startDate).toEqual(new Date('2015-1-1'));
    expect(enrollments[1].endDate).toEqual(new Date('2016-1-1'));       
    expect(enrollments[1].student.id).toEqual(1);
    expect(enrollments[1].student.cardNumber).toEqual('a123');
    expect(enrollments[1].student.firstName).toEqual('Petar');
    expect(enrollments[1].student.lastName).toEqual('Petrovic');
    expect(enrollments[1].course.id).toEqual(8);
    expect(enrollments[1].course.name).toEqual('Programiranje');
  })); 


  it('announceChange() should emit the event RegenerateData', fakeAsync(() => {
    let counter: number = 0;
    studentService.RegenerateData$.subscribe(() =>  counter++);

    studentService.announceChange();
    tick();
    studentService.announceChange();
    tick();

    expect(counter).toBe(2);
  }));
});