import { Injectable } from '@angular/core';
import { HttpResponse, HttpClient } from '@angular/common/http';
import {Observable, Subject} from 'rxjs';

import { Course } from '../model/course.model';
import { Enrollment } from '../model/enrollment.model';

@Injectable()
export class CourseService {
    private coursesUrl = 'api/courses';

    constructor(private http: HttpClient) { }

    private RegenerateData = new Subject<void>();

    RegenerateData$ = this.RegenerateData.asObservable();

    announceChange() {
        this.RegenerateData.next();
    }
    
    getCourses(): Observable<HttpResponse<Course[]>> {
        return this.http.get<Course[]>(this.coursesUrl, {observe: 'response'});
    }

    getCourse(id: number): Observable<HttpResponse<Course>> {
        const url = `${this.coursesUrl}/${id}`;
        return this.http.get<Course>(url, {observe: 'response'});
    }

    addCourse(course: Course): Observable<HttpResponse<Course>> {
        return this.http.post<Course>(this.coursesUrl, course, {observe: 'response'});
    }

    editCourse(course: Course): Observable<HttpResponse<Course>> {
        return this.http.put<Course>(this.coursesUrl, course, {observe: 'response'});
    }

    deleteCourse(courseId: number): Observable<HttpResponse<any>> {
        const url = `${this.coursesUrl}/${courseId}`;
        return this.http.delete<any>(url, {observe: 'response'});
    }

    getCourseEnrollments(courseId: number): Observable<HttpResponse<Enrollment[]>> {
        const url = `${this.coursesUrl}/${courseId}/students`;
        return this.http.get<Enrollment[]>(url, {observe: 'response'});
    }
}