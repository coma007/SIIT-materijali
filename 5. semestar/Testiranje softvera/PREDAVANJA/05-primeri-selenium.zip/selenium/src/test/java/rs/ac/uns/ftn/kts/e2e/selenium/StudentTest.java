package rs.ac.uns.ftn.kts.e2e.selenium;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertFalse;
import static org.testng.AssertJUnit.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class StudentTest {
	
	private WebDriver browser;
	
	@BeforeMethod
	public void setupSelenium() {
		//instantiate browser
		System.setProperty("webdriver.chrome.driver", "C:/javatools/selenium-chrome-driver-2018/chromedriver.exe");
		browser = new ChromeDriver();
		//maximize window
		browser.manage().window().maximize();
		//navigate
		browser.navigate().to("http://localhost:8080");
	}
	
	@Test
	public void testAddStudent() throws InterruptedException {
		WebElement studentsMenu = (new WebDriverWait(browser, 10))
				  .until(ExpectedConditions.elementToBeClickable(
						  By.cssSelector("li > a:first-of-type")));
		studentsMenu.click(); //opens students list
		
		// wait for page to load
		WebElement addButton = (new WebDriverWait(browser, 10))
				  .until(ExpectedConditions.presenceOfElementLocated(
						  By.cssSelector("button[aria-label=\"Add\"]")));
		
		//get number of table rows before adding new student (including header row)
		int noOfTableRows = browser.findElements(By.cssSelector("tr")).size();
		
		//open student-add page
		assertTrue(addButton.isDisplayed());
		addButton.click();
		
		// check the page is displayed
		assertEquals("http://localhost:8080/#/addStudent", browser.getCurrentUrl());
		
		//get input elements
		WebElement inputCard = browser.findElement(By.id("field1c"));
		WebElement inputFirstName = browser.findElement(By.id("field2c"));
		WebElement inputLastName = browser.findElement(By.id("field3c"));
		
		assertEquals(inputCard.isDisplayed(), true);
		assertEquals(inputFirstName.isDisplayed(), true);
		assertEquals(inputLastName.isDisplayed(), true);
		//enter student data
		inputCard.sendKeys("ra1-2016");
		inputFirstName.sendKeys("Dejan");
		inputLastName.sendKeys("Dejanović");
		
		// wait for ok button to be available
		WebElement okButton = browser.findElement(By.xpath("//button[2]"));
		//save test student
		okButton.click();
		
		// wait for students page to load again
		(new WebDriverWait(browser, 10))
		  .until(ExpectedConditions.numberOfElementsToBe(
				  By.cssSelector("tr"), noOfTableRows + 1));
		
		//check that new student has been added
		assertEquals(noOfTableRows + 1, browser.findElements(By.cssSelector("tr")).size());
		WebElement tdCardNumber = browser.findElement(By.xpath("//tr[last()]/td[1]"));
		assertEquals(tdCardNumber.getText(), "ra1-2016");
		WebElement tdFirstName = browser.findElement(By.xpath("//tr[last()]/td[2]"));
		assertEquals(tdFirstName.getText(), "Dejan");
		WebElement tdLastName = browser.findElement(By.xpath("//tr[last()]/td[3]"));
		assertEquals(tdLastName.getText(), "Dejanović");
		
		//delete test student
		WebElement deleteButton = browser.findElement(
				By.xpath("//tr[last()]/td[4]/button[2]"));
		deleteButton.click();		
		
		//wait for remove table row
		(new WebDriverWait(browser, 10))
		  .until(ExpectedConditions.invisibilityOfElementLocated(
				  By.xpath("//tr[" + (noOfTableRows + 1) + "]")));
		
		tdCardNumber = browser.findElement(By.xpath("//tr[last()]/td[1]"));
		assertFalse(tdCardNumber.getText().equals("ra1-2016"));
		tdFirstName = browser.findElement(By.xpath("//tr[last()]/td[2]"));
		assertFalse(tdFirstName.getText().equals("Dejan"));
		tdLastName = browser.findElement(By.xpath("//tr[last()]/td[3]"));
		assertFalse(tdLastName.getText().equals("Dejanović"));
	}
	
	@AfterMethod
	public void closeSelenium() {
		// Shutdown the browser
		browser.quit();
	}	
}
