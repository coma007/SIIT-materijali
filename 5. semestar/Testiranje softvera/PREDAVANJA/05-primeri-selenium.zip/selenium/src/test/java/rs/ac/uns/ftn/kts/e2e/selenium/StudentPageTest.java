package rs.ac.uns.ftn.kts.e2e.selenium;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertFalse;
import static org.testng.AssertJUnit.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import rs.ac.uns.ftn.kts.e2e.selenium.pages.MenuPage;
import rs.ac.uns.ftn.kts.e2e.selenium.pages.StudentEditPage;
import rs.ac.uns.ftn.kts.e2e.selenium.pages.StudentListPage;

public class StudentPageTest {
	private WebDriver browser;
	
	MenuPage menuPage;
	StudentListPage studentListPage;
	StudentEditPage studentEditPage;
	
	@BeforeMethod
	public void setupSelenium() {
		//instantiate browser
		System.setProperty("webdriver.chrome.driver", "C:/javatools/selenium-chrome-driver-2018/chromedriver.exe");
		browser = new ChromeDriver();
		//maximize window
		browser.manage().window().maximize();
		//navigate
		browser.navigate().to("http://localhost:8080");
		
		menuPage = PageFactory.initElements(browser, MenuPage.class);
		studentListPage = PageFactory.initElements(browser, StudentListPage.class);
		studentEditPage = PageFactory.initElements(browser, StudentEditPage.class);
	}
	
	@Test
	public void testAddStudent() {
		// get menu element
		menuPage.ensureIsDisplayed();
		menuPage.getStudentsLink().click();
		
		assertEquals("http://localhost:8080/#/students", browser.getCurrentUrl());
		
		//ensure can start adding
		studentListPage.ensureIsDisplayed();
		
		//save size of student list (without new student)
		int noOfStudents = studentListPage.getStudentsTableSize();
		
		//open add student page
		assertTrue(studentListPage.getAddButton().isDisplayed());
		studentListPage.getAddButton().click();		

		//check are input elements displayed
		assertTrue(studentEditPage.getInputCard().isDisplayed());
		assertTrue(studentEditPage.getInputFirstName().isDisplayed());
		assertTrue(studentEditPage.getInputLastName().isDisplayed());
		//enter student data
		studentEditPage.setInputCard("ra1-2016");
		studentEditPage.setInputFirstName("Dejan");
		studentEditPage.setInputLastName("Dejanović");
		
		//save test student
		studentEditPage.getOkButton().click();
		
		//wait for adding new student
		studentListPage.ensureIsAdded(noOfStudents);
		
		//check that new student has been added
		assertEquals(noOfStudents + 1, studentListPage.getStudentsTableSize());
		assertEquals(studentListPage.getLastTdCard().getText(), "ra1-2016");
		assertEquals(studentListPage.getLastTdFirstName().getText(), "Dejan");
		assertEquals(studentListPage.getLastTdLastName().getText(), "Dejanović");
		
		//delete test student
		studentListPage.getDeleteButton().click();		
		
		//wait for remove table row
		studentListPage.ensureIsDeleted(noOfStudents);
		
		assertFalse(studentListPage.getLastTdCard().getText().equals("ra1-2016"));
		assertFalse(studentListPage.getLastTdFirstName().getText().equals("Dejan"));
		assertFalse(studentListPage.getLastTdLastName().getText().equals("Dejanović"));
	}
	
	@AfterMethod
	public void closeSelenium() {
		// Shutdown the browser
		browser.quit();
	}	
}
