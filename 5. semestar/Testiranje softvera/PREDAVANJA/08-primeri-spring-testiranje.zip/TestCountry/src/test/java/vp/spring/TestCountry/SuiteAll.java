package vp.spring.TestCountry;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import vp.spring.TestCountry.data.CountryRepositoryIntegrationTest;
import vp.spring.TestCountry.data.CountryRepositoryUnitTest;
import vp.spring.TestCountry.service.CountryServiceIntegrationTest;
import vp.spring.TestCountry.service.CountryServiceUnitTest;
import vp.spring.TestCountry.web.controller.CountryControllerTest;

@RunWith(Suite.class)
@SuiteClasses({CountryRepositoryUnitTest.class, 
		CountryRepositoryIntegrationTest.class,
		CountryServiceUnitTest.class,
		CountryServiceIntegrationTest.class,
		CountryControllerTest.class})
public class SuiteAll {

}
