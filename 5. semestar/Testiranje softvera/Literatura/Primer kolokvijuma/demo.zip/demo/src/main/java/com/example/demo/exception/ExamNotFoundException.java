package com.example.demo.exception;

public class ExamNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExamNotFoundException(String message) {
		super(message);
	}
}
