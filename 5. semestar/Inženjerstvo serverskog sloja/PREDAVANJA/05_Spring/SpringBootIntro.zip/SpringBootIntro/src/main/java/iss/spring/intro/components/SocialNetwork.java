package iss.spring.intro.components;

public interface SocialNetwork {
	public void publishMessage(String message);
}
