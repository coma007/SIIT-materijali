package iss.spring.web.services.interfaces;

import java.util.Collection;

import iss.spring.web.entities.City;

public interface ICityService {
	public Collection<City> getAll();
}
