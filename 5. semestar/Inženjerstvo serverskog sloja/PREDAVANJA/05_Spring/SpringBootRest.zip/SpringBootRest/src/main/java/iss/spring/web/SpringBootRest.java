package iss.spring.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication 
public class SpringBootRest {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRest.class, args);
	}

}
