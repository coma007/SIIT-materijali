package iss.spring.security.services.interfaces;

import java.util.Collection;

import iss.spring.security.entities.City;


public interface ICityService {
	public Collection<City> getAll();
}
