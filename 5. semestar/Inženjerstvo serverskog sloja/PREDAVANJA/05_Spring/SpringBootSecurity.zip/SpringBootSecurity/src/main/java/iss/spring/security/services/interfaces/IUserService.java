package iss.spring.security.services.interfaces;

import iss.spring.security.entities.User;

public interface IUserService {
	public User login(User user);
}
