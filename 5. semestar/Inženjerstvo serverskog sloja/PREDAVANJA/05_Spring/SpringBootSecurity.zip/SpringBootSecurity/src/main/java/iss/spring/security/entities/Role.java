package iss.spring.security.entities;

public enum Role {
    USER, ADMIN, ANONYMOUS
}