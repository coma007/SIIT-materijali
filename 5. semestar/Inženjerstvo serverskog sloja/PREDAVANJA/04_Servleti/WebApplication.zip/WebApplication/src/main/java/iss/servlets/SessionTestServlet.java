package iss.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import iss.beans.session.SessionCounter;

/**
 * Servlet implementation class SessionTestServlet
 */
@WebServlet("/SessionTestServlet")
public class SessionTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionTestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>Session Counter Test</title></head>");
		out.println("<body>");

		// uzimanje reference na objekat koji reprezentuje http sesiju
		HttpSession session = request.getSession();
		
		// podaci o sesiji
		out.println("<b>Sesija ID:" + session.getId() + "</b>");
		
		/*
		 * Probamo da pokupimo brojac pristupa u ovoj sesiji (koji je dodeljen ovoj sesiji).
		 * Ukoliko je objekat != od null, sledi da je objekat vec dodat sesiji, inace,
		 * kreira se novi objekat i dodaje se sesiji.
		 * Kljuc pod kojim se objekat dodaje sesiji (u ovom primeru) je "brojac".
		 */
		SessionCounter sc = (SessionCounter) session.getAttribute("brojac");
		if ( sc == null ) {
			out.println(", prvi pristup.");
			sc = new SessionCounter();
			session.setAttribute("brojac", sc);
		}
		sc.inc();
		out.println("<br />Ukupno pristupa:" + sc.getCount() + ".<br />");
		out.println("<p>");
		out.println("<a href=\"index.html\">Nazad</a>");
		out.println("</p>");
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
