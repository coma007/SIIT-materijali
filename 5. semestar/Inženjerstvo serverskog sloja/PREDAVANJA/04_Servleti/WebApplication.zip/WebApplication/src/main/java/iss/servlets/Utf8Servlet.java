package iss.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Utf8Servlet
 */
@WebServlet("/Utf8Servlet")
public class Utf8Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Utf8Servlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// !!! PAZNJA !!! Obratiti paznju na setovanje charset-a na UTF-8
		// ovim se govori da se podaci koji se pisu u stream ka klijentu enkodiraju
		// UTF-8 kodnom stranom
		response.setContentType("text/html; charset=UTF-8");

		PrintWriter pout = response.getWriter();
		pout.println("<html>");
		pout.println("<head>");

		// !!! Paznja !!!
		// Ovim se saopstava http klijentu (browseru) kako da interpretira podatke iz
		// stream-a
		pout.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
		pout.println("</head>");
		pout.println("<body>");

		try {
			pout.println("Ovo je stranica sa UTF-8 karakterima: \u0428 \u0429 ћирилица<br>");
		} catch (Exception ex) {
			pout.println(ex.getMessage());
		}
		
		pout.println("<p>");
		pout.println("<a href=\"index.html\">Nazad</a>");
		pout.println("</p>");

		pout.println("</body>");
		pout.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
