package dynamiclistener.listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import javax.swing.JButton;

import dynamiclistener.annotations.ActionListenerFor;


/**
 * Skenira prosleđeni objekat i traži metode označene anotacijom ActionListener, pa
 * takve metode dinamički pretvara u listenere.
 * @author minja
 *
 */
public class ActionListenerInstaller {
	@SuppressWarnings("rawtypes")
	/**
	 * Skenira sve metode u prosleđenoj klasi.
	 * @param obj Objekat klase u kojoj se nalaze metode koje ćemo 
	 * 			  proglasiti za listenere. Obično je to klasa naslednica
	 * 			  klase JFrame.
	 */
	public static void processAnnotations(Object frame) {
		try {
			Class cl = frame.getClass();
			for (Method m : cl.getDeclaredMethods()) {
				ActionListenerFor a = m.getAnnotation(ActionListenerFor.class);
				if (a != null) {
					// pronadji atribut cije ime je u anotaciji
					// (source="redButton")
					Field f = cl.getDeclaredField(a.source());
					f.setAccessible(true);
					// dodaj ActionListener na to dugme
					addListener(f.get(frame), frame, m);
					//addProxyListener(f.get(frame), frame, m);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void addListener(Object button, final Object frame,
			final Method m) {
		((JButton)button).addActionListener(new UniversalActionListener(frame, m));
	}


	/**
	 * Dodaje dinamicki ActionListener na prosleđenu GUI komponentu
	 * 
	 * @param button
	 *            GUI komponenta na koju dodajemo ActionListener
	 * @param frame
	 *            GUI kontejner u kojem se nalazi komponenta (frame)
	 * @param m
	 *            Metod iz kontejnera koji sadrzi anotaciju ActionListenerFor i
	 *            koji bi trebalo da se pozove kada kod se dogodi ActionEvent
	 **/
	public static void addProxyListener(Object button, final Object frame,
			final Method m) throws NoSuchMethodException,
			IllegalAccessException, InvocationTargetException {
		InvocationHandler handler = new InvocationHandler() {
			public Object invoke(Object proxy, Method mm, Object[] args)
					throws Throwable {
				// kada god se pozove metoda actionPerformed ActionListener
				// interfejsa,
				// poziva se InvocationHandler.invoke metoda
				// ovde cemo pozvati onu metodu iznad koje stoji anotacija
				// ActionListenerFor
				// parametar mm sadrzi metod koji je pozvan, ali ActionListener
				// ima jednu metodu
				m.setAccessible(true);
				return m.invoke(frame);
			}
		};

		/* Ključni element je Proxy klasa. Ona omogućuje da se napravi dinamička klasa 
		 * koja još i implementira zadati interfejs. Nju ćemo prijaviti kao listener tako
		 * što ćemo je napraviti i proslediti kao argment metodi addActionListener() prosleđene
		 * GUI komponente (JButton). 
		 *  
		 */
		Object listener = Proxy.newProxyInstance(null,
				new Class[] { java.awt.event.ActionListener.class }, handler);
		
		// Pronađemo metodu addActionListener() u GUI source komponenti (JButton).  
		Method adder = button.getClass().getMethod("addActionListener",
				ActionListener.class);
		// Pozovemo tu metodu.
		adder.invoke(button, listener);
	}

}

class UniversalActionListener implements ActionListener {
	private Object frame;
	private Method m;
	public UniversalActionListener(Object frame, Method m) {
		this.frame = frame;
		this.m = m;
	}
	@Override
	public void actionPerformed(ActionEvent arg) {
		try {
			m.setAccessible(true);
			m.invoke(frame);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			e.printStackTrace();
		}
	}
	
}