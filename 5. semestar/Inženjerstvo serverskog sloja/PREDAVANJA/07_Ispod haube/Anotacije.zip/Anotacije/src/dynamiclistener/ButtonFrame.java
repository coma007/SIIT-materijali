package dynamiclistener;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import dynamiclistener.annotations.ActionListenerFor;
import dynamiclistener.listeners.ActionListenerInstaller;


class ButtonFrame extends JFrame {
	private static final long serialVersionUID = -3780952204929777088L;
	private JPanel panel;
	private JButton blueButton, redButton;

	public ButtonFrame() {
		setTitle("ButtonTest");
		setSize(640, 480);
		panel = new JPanel();
		add(panel);
		blueButton = new JButton("Blue");
		redButton = new JButton("Red");
		panel.add(blueButton);
		panel.add(redButton);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Skeniramo metode, proveravamo anotacije i dodeljujemo listenere
		ActionListenerInstaller.processAnnotations(this);
	}

	@ActionListenerFor(source = "blueButton")
	public void blueBackground() {
		panel.setBackground(Color.BLUE);
	}

	@ActionListenerFor(source = "redButton")
	public void redBackground() {
		panel.setBackground(Color.RED);
	}

	public static void main(String[] args) {
		new ButtonFrame().setVisible(true);
	}
}
