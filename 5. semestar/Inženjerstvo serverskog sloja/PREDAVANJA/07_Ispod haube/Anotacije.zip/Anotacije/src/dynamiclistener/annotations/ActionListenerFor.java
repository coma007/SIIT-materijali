package dynamiclistener.annotations;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
/** 
 * Postavlja se iznad metode koju želimo da proglasimo za listener na ActionEvent 
 * 
 * @author minja
 *
 */
public @interface ActionListenerFor {
	/** 
	 * Atribut anotacije kojim se označava ime JButton komponente
	 *  na koju reagujemo (kada se klikne na nju).
	 * 
	 * @return
	 */
	String source();
}
