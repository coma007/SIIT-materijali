package di;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public class DependencyInjectionManager {

	public static void process(Object obj) {
		Class<?> clazz = obj.getClass();
		Field[] fields = clazz.getDeclaredFields();
		for (Field f : fields) {
			Autowired a = f.getAnnotation(Autowired.class);
			if (a != null) {
				Class<?> c = f.getType();
				try {
					Object instance = c.getDeclaredConstructor().newInstance();
					f.set(obj, instance);
				} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
						| InvocationTargetException | NoSuchMethodException | SecurityException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
