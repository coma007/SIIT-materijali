package di;

@Component
public class MyBean {

	@Override
	public String toString() {
		return "MyBean instance";
	}

}
