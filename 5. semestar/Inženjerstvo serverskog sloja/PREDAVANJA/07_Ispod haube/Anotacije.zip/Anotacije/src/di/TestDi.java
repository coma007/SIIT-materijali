package di;

public class TestDi {
	
	@Autowired
	MyBean comp;
	
	public TestDi() {
		System.out.println(comp);
	}

	public static void main(String[] args) {
		TestDi t = new TestDi();
		
		DependencyInjectionManager.process(t);
		
		System.out.println(t.comp);
	}

}
