package di;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class DependencyInjectionManager {

	@Pointcut("initialization(*.new(..)) && @within(di.Component)")
	void adviceNew() {
	}
	
	@Before("adviceNew()")
	public void beforeWrapper(JoinPoint jp) throws Throwable {
		Object target = jp.getTarget();
		process(target);
	}
	
	public static void process(Object obj) {
		Class<?> clazz = obj.getClass();
		Field[] fields = clazz.getDeclaredFields();
		for (Field f : fields) {
			Autowired a = f.getAnnotation(Autowired.class);
			if (a != null) {
				Class<?> c = f.getType();
				try {
					Object instance = c.getDeclaredConstructor().newInstance();
					f.set(obj, instance);
				} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
						| InvocationTargetException | NoSuchMethodException | SecurityException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
