package di;

//Startovati sa ovim parametrima:
//-javaagent:lib\aspectjweaver.jar --add-opens java.base/java.lang=ALL-UNNAMED

@Component
public class TestDiAop {
	
	@Autowired
	MyBean comp;
	
	
	public TestDiAop() {
		System.out.println(comp);
	}
	
	public static void main(String[] args) {
		TestDiAop t = new TestDiAop();
		System.out.println(t.comp);
	}

}
