package iss.aop;

public class Drugi {
	Test p;
	public Drugi(Test p) {
		super();
		this.p = p;
	}
	public void d() {
		p.f2("asdfghjkl");
	}
	
	public void d2() {
		p.f4();
	}
	
	static {
		System.out.println("Staticki blok.");
	}
}
