package iss.aop;


// Startovati sa ovim parametrima:
// -javaagent:lib\aspectjweaver.jar --add-opens java.base/java.lang=ALL-UNNAMED
@SuppressWarnings("unused")
public class Test {

	private int attr1;

	@MojaAnotacija
	private int attr2;

	private int attr3;

	public Test() {
		attr1 = 1;
		attr2 = 2;
		attr3 = 3;
	}

	public void f() {

	}

	public int f2(String b) {
		return b.length();
	}

	public void f3() throws Exception {
		throw new Exception("tekst izuzetka");
	}

	public void f4() {
		System.out.println("Zabranjena metoda!");
	}

	public static void main(String[] args) {
		Test p = new Test();
		p.f();
		p.f2("asdf");

		try {p.f3();} catch(Exception ex) {ex.printStackTrace();} 
		
		Drugi d = new Drugi(p);
		d.d();
		d.d2();
		
		// zabranjen poziv!
		//p.f4();
	}
}
