package iss.aop;

import java.lang.reflect.Field;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.DeclareError;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class Aspekti {
	// pointcut okoF koji cemo pozivati u vezi sa funkcijom f() klase Test
	@Pointcut ( "call( public void Test.f()) " )
	void okoF() {}

	@Around("okoF()")
	public void aroundOkoF(ProceedingJoinPoint jp) {
		System.out.println("* okoF(), pre poziva funkcije f()");
		try {
			jp.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		System.out.println("* okoF(), posle poziva funkcije f()");
		//throw new RuntimeException ("BOOM!");
	}
	

	// pointcut univerzalni koji cemo pozivati u vezi sa pozivom bilo koje metode klase Test
	@Pointcut ( "call(* Test.*(..))" )
	void univerzalni() {}

	@Around("univerzalni()")
	public Object aroundUniverzalni(ProceedingJoinPoint jp) throws Throwable {
		Object ret = null;
		Object[] args = jp.getArgs();
		Object caller = jp.getThis();
		Object callee = jp.getTarget();

		System.out.println("&& univerzalni(), pre poziva " + jp.getSignature().getDeclaringTypeName() + "." + jp.getSignature().getName());
		System.out.println("&& Pozvao: " + caller + ", a pozvan: " + callee);
		System.out.print("&&  Br. argumenata: " + args.length + ":\t");
		for (int i = 0; i < args.length; i++)
			System.out.print(args[i] + " ");
		System.out.println();
			ret = jp.proceed();
		System.out.println("&& univerzalni(), posle poziva " + jp.getSignature().getName() + ",a rezultat je: " + ret);
		return ret;
	}
	
	/* Pomocna metoda koja vraca vrednost zadatog atributa */
	public static Object getValueFrom(Object obj, String fieldName) {
		try {
			Field f = obj.getClass().getDeclaredField(fieldName);
			f.setAccessible(true);
			return f.get(obj);
		} catch (Exception ex) {
			return null;
		}
	}
	
	/* Pomocna metoda koja vraca ime atributa na osnovu rezultate metode
	 * thisJoinPoint.toShortString() 
	 */
	public static String extractFieldName(String n) {
System.out.println("*** ExtractFieldName: " + n);
		int idx = n.lastIndexOf('.');
		if (idx != -1) {
			return n.substring(idx + 1, n.length()-1);
		} else
			return n;
	}
	
	@Pointcut("set (private int *..Test.attr1)")
	void atribut1(){}
	@Around("atribut1()")
	public void aroundAtribut1(JoinPoint thisJoinPoint, ProceedingJoinPoint jp) {
		String fieldName = thisJoinPoint.getSignature().getName();
		System.out.println("[atribut1()] Pre menjanja atributa " + fieldName + " vrednost: " +
			getValueFrom(thisJoinPoint.getTarget(), extractFieldName(thisJoinPoint.toShortString())));
		try {
			jp.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		System.out.println("[atribut1()] Posle menjanja atributa " + fieldName + " vrednost: " + 
			getValueFrom(thisJoinPoint.getTarget(), extractFieldName(thisJoinPoint.toShortString())));
	}
	

	
	@Pointcut("set (private * iss.aop.Test.*) && (@annotation(iss.aop.MojaAnotacija))")
	void atribut2(){}
	@Around("atribut2()")
	public void aroundAtributSaAnotacijom(JoinPoint thisJoinPoint, ProceedingJoinPoint jp) {
		String fieldName = thisJoinPoint.getSignature().getName();
		System.out.println("[@atributSaAnotacijom()] Pre menjanja atributa " + fieldName + " vrednost: " +
			getValueFrom(thisJoinPoint.getTarget(), extractFieldName(thisJoinPoint.toShortString())));
		try {
			jp.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		System.out.println("[@atributSaAnotacijom()] Posle menjanja atributa " + fieldName + " vrednost: " +
			getValueFrom(thisJoinPoint.getTarget(), extractFieldName(thisJoinPoint.toShortString())));
	}
	
	
	@Pointcut("handler (Exception+) && within(Test)")
	void izuzetak() {}
	@Before("izuzetak()") 
	public void beforeIzuzetak(JoinPoint thisJoinPoint) {
		System.out.println("## izuzetak(): ");
		Object[] args = thisJoinPoint.getArgs();
		System.out.print("##  Br. argumenata: " + args.length + ":\t");
		for (int i = 0; i < args.length; i++)
			System.out.print(args[i] + " ");
		System.out.println();
		System.out.println("## izuzetak(), kraj ");
	}

	@Pointcut("staticinitialization(Drugi)")
	void staticInit() {}
	@After("staticInit()")
	public void afterStaticInit() {
		System.out.println("!!!! Posle static bloka");
	}
	
	
	@DeclareError( "call ( * iss.aop.Test.f4() ) && within (Test)" )
	final static String message = "Poziv metode f4() je zabranjen!";

}
