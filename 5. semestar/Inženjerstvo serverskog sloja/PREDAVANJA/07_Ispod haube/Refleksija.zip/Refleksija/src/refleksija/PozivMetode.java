package refleksija;

import java.lang.reflect.Method;

public class PozivMetode {
	
	@SuppressWarnings("unused")
	private int strlen(String s) {
		return s.length();
	}
	
	@SuppressWarnings("unused")
	private static void f() {
		System.out.println("Metoda f");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void invokeMethod() {
		try {
			Class cl = Class.forName("refleksija.PozivMetode");
//			Class cl = this.getClass();
			Method mtdF = cl.getDeclaredMethod("f");
			mtdF.invoke(null);

			Method mtd = cl.getDeclaredMethod("strlen", String.class);
			mtd.setAccessible(true);
			Object obj = cl.getDeclaredConstructor().newInstance();
			int len = (Integer) mtd.invoke(obj, "Test1");
			System.out.println(len);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new PozivMetode().invokeMethod();
	}
}
