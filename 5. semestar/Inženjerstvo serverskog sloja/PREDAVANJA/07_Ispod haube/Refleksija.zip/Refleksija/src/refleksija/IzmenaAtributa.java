package refleksija;

import java.lang.reflect.Field;

public class IzmenaAtributa {
	
	@SuppressWarnings("rawtypes")
	public static void main(String[] args) {
		try {
//			Class cl = Class.forName("refleksija.TestKlasa");
//			Object obj = cl.newInstance();
			TestKlasa obj = new TestKlasa();
			Class cl = obj.getClass();
			
			Field f = cl.getDeclaredField("a");
			f.setAccessible(true);  // <<<<<<<<<<<<<<<<<<<<<
			
			System.out.println("Vrednost atributa a je: " + f.getInt(obj));
			f.setInt(obj, 5);
			System.out.println("Vrednost atributa a je: " + f.getInt(obj));
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
//		} catch (InstantiationException e) {
//			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}
	
}

class TestKlasa {
	@SuppressWarnings("unused")
	private int a = 9; 
}
