package refleksija;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.logging.Logger;

public class AtributiMetodeKonstruktori {

	Logger log = Logger.getLogger(getClass().getName()); 
	
	@SuppressWarnings("unused")
	private static int a = 9;
	
	double d = Math.PI;
	
	@SuppressWarnings("rawtypes")
	private AtributiMetodeKonstruktori(String className) {
		Class cl;
		try {
			cl = Class.forName(className);
			printFields(cl);
			printMethods(cl);
			printConstructors(cl);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("rawtypes")
	private void printFields(Class cl) {
		System.err.println("Fields:");
		
		Field[] fields = cl.getDeclaredFields();	// fields
//		Field[] fields = cl.getFields();			// public&inherited fields
		for (Field f : fields) {
			String modifier = Modifier.toString(f.getModifiers());
			Class type = f.getType();
			String name = f.getName();
			System.out.println(modifier + " " + type + " " + name + "\n");
		}
	}

	@SuppressWarnings("rawtypes")
	private void printMethods(Class cl) {
		System.err.println("Methods:");
		
		Method[] methods = cl.getDeclaredMethods(); // methods
//		Method[] methods = cl.getMethods();  		// public&inherited methods
		for (Method m : methods) {
			String modifier = Modifier.toString(m.getModifiers());
			Class retType = m.getReturnType();
			String name = m.getName();
			System.out.print(modifier + " " + retType + " " + name + "(");

			Class[] paramTypes = m.getParameterTypes();
			for (int i = 0; i < paramTypes.length; i++) {
				if (i > 0)
					System.out.print(", ");
				System.out.print(paramTypes[i].getName());
			}
			System.out.println(")");
		}
	}

	@SuppressWarnings("rawtypes")
	private void printConstructors(Class cl) {
		System.err.println("Constructors:");
		
		Constructor[] consts = cl.getDeclaredConstructors(); // ALL contructors
//		Constructor[] consts = cl.getConstructors();  		 // public contructors
		for (Constructor c : consts) {
			String modifier = Modifier.toString(c.getModifiers());
			String name = c.getName();
			System.out.print(modifier + " " + name + "(");

			Class[] paramTypes = c.getParameterTypes();
			for (int i = 0; i < paramTypes.length; i++) {
				if (i > 0)
					System.out.print(", ");
				System.out.print(paramTypes[i].getName());
			}
			System.out.println(")");
		}
	}
	
	@SuppressWarnings("unused")
	private int[] test(Object[] a, String[] s) {
		return null;
	}

	void fdouble(double[] a) {
		
	}
	void fint(int[] a, int i) {
		
	}
	void fboolean(boolean[] a) {
		
	}
	void fbyte(byte[] a) {
		
	}
	void fstring(String[] a) {
		
	}

	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		String s = sc.nextLine();
//		new AtributiMetodeKonstruktori(s);
//		new AtributiMetodeKonstruktori("java.lang.String");
//		new AtributiMetodeKonstruktori("javax.swing.JButton");
		new AtributiMetodeKonstruktori("refleksija.AtributiMetodeKonstruktori");
	}

}
