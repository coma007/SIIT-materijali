package primer02threadsync;

public class Counter {
	public int count;
}
