package primer02threadnosinc;

public class Counter {
	public int count;
}
