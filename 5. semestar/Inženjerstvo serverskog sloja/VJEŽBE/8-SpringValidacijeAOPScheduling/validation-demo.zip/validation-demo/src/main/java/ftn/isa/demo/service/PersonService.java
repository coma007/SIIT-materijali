package ftn.isa.demo.service;

import ftn.isa.demo.model.Person;
import org.springframework.stereotype.Service;

@Service
public class PersonService {

    public Person createPerson(Person person) {
        return null;
    }
}
