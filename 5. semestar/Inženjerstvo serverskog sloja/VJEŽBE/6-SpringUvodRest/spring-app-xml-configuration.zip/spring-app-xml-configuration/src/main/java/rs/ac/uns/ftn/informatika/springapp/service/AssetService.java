package rs.ac.uns.ftn.informatika.springapp.service;

import java.util.List;

import rs.ac.uns.ftn.informatika.springapp.domain.Asset;

public interface AssetService {

	List<Asset> listAssets();
}
