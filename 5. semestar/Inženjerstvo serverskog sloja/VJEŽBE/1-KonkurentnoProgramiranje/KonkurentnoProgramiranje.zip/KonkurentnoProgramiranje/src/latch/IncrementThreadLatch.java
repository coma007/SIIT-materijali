package latch;

import java.util.concurrent.CountDownLatch;

import primer.ValueHolder;

public class IncrementThreadLatch extends Thread {
	private ValueHolder vh;
	private CountDownLatch latch;

	public IncrementThreadLatch(ValueHolder vh, CountDownLatch latch) {
		this.vh = vh;
		this.latch = latch;
	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				// Sleep je neophodan da bi se izvr�avanje usporilo dovoljno da izazove anomalije
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
			vh.setValue(vh.getValue() + 1);
		}
		this.latch.countDown();
	}
}
