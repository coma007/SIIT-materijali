package thread;

import primer.ValueHolder;

public class IncrementRunnable implements Runnable {
	private ValueHolder vh;

	public IncrementRunnable(ValueHolder vh) {
		this.vh = vh;
	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				// Sleep je neophodan da bi se izvr�avanje usporilo dovoljno da izazove
				// anomalije
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
			vh.setValue(vh.getValue() + 1);
		}
	}

}
