package primer;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import latch.IncrementThreadLatch;
import thread.IncrementThread;

public class Main {
	
	private static void primerJoin() {
		ValueHolder vh = new ValueHolder();
		List<Thread> threads = new ArrayList<>();
		for (int i = 0; i < 100; i++) {
			Thread t = new IncrementThread(vh);
			// Za Runnable
			// Thread t = new Thread(new IncrementRunnable(vh));
			t.start();
			threads.add(t);
		}

		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		}

		System.out.println(vh.getValue());
	}
	
	private static void primerLatch() {
		ValueHolder vh = new ValueHolder();
		CountDownLatch latch = new CountDownLatch(100);
		for (int i = 0; i < 100; i++) {
			Thread t = new IncrementThreadLatch(vh, latch);
			// Za Runnable
			// Thread t = new Thread(new IncrementRunnableLatch(vh, latch));
			t.start();
		}
		
		try {	
			latch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
			return;
		}

		System.out.println(vh.getValue());
	}
	
	private static void primerExecutor() {
		ValueHolder vh = new ValueHolder();
		ExecutorService pool = Executors.newFixedThreadPool(10);
		for (int i = 0; i < 100; i++) {
			pool.execute(new IncrementThread(vh));
			// Za Runnable
			// pool.execute(new IncrementRunnable(vh));
		}
		
		// Započni gašenje i odbij nove zahteve
		pool.shutdown();
		// Čekaj najviše 100 sekundi da se sve niti završe
		try {
			pool.awaitTermination(100, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
			return;
		}

		System.out.println(vh.getValue());
	}
	
	public static void main(String[] args) {
//		primerJoin();
//		primerLatch();
		primerExecutor();
	}
}
