/**
 * 
 */
package primer4;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import net.miginfocom.swing.MigLayout;

/**
 * @author Danijel
 * 
 */
public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1007785622881149826L;

	private JLabel lblDosije;
	private JTextField tfDosije;
	private JCheckBox cbAktivan;
	
	private JLabel lblIme;
	private JTextField tfIme;
	private JLabel lblOpis;
	private JTextArea taOpis;
	
	private JLabel lblCopyright;

	private JButton btnOK;
	private JButton btnCancel;

	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		initComponents();

		pack();

		setLocationRelativeTo(null);
	}

	private void initComponents() {
		setLayout(new MigLayout("debug", "[]10[grow]", "[][]10[grow]30[]"));

		lblDosije = new JLabel("Broj indeksa");
		tfDosije = new JTextField(30);

		lblIme = new JLabel("Ime i prezime");
		tfIme = new JTextField(30);

		lblOpis = new JLabel("Opis");
		taOpis = new JTextArea(10, 50);

		btnOK = new JButton("Potvrda");
		btnCancel = new JButton("Odustanak");
		
		cbAktivan = new JCheckBox("Aktivan?");
		
		lblCopyright = new JLabel("Copyright FTN, 2015");
		lblCopyright.setForeground(Color.RED);
		lblCopyright.setOpaque(false);

		add(lblDosije, "cell 0 0, aligny top");
		add(tfDosije, "cell 1 0, flowy, width 10mm:50mm:100mm, height 10mm:10mm:10mm, gapy null 10px");
		add(cbAktivan, "cell 1 0, gapy null 20px");
		add(lblIme, "cell 0 1");
		add(tfIme, "cell 1 1, growx, width 10%:null:max(pref+20px, 80%)");
		add(lblOpis, "cell 0 2, aligny top");
		add(taOpis, "cell 1 2, growx, growy");
		add(btnOK, "id bok, cell 0 3, span 2 1, tag ok");
		add(btnCancel, "cell 0 3,  tag cancel");
		add(lblCopyright, "pos max((bok.x-pref-10px), 0) (bok.y)");
		
	}

}
