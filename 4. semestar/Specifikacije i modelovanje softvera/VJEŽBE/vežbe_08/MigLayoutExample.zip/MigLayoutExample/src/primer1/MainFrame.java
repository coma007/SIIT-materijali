/**
 * 
 */
package primer1;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import net.miginfocom.swing.MigLayout;

/**
 * @author Danijel
 * 
 */
public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1007785622881149826L;

	private JLabel lblDosije;
	private JTextField tfDosije;
	private JLabel lblIme;
	private JTextField tfIme;
	private JLabel lblOpis;
	private JTextArea taOpis;

	private JButton btnOK;
	private JButton btnCancel;

	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		initComponents();

		pack();

		setLocationRelativeTo(null);
	}

	private void initComponents() {
		setLayout(new MigLayout());

		lblDosije = new JLabel("Broj indeksa");
		tfDosije = new JTextField(30);

		lblIme = new JLabel("Ime i prezime");
		tfIme = new JTextField(50);

		lblOpis = new JLabel("Opis");
		taOpis = new JTextArea(10, 50);

		btnOK = new JButton("Potvrda");
		btnCancel = new JButton("Odustanak");

		add(lblDosije);
		add(tfDosije, "wrap");
		add(lblIme);
		add(tfIme, "wrap");
		add(lblOpis);
		add(taOpis, "wrap");
		add(btnOK);
		add(btnCancel);
	}

}
