/**
 * 
 */
package primer5;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

import net.miginfocom.swing.MigLayout;

/**
 * @author Danijel
 * 
 */
public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1007785622881149826L;

	private JLabel lblNorth;
	private JLabel lblSouth;
	private JLabel lblWest;
	private JLabel lblEast;
	private JTextArea taCenter;
	private JButton btnOK;
	


	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		initComponents();

		pack();

		setLocationRelativeTo(null);
	}

	private void initComponents() {
		setLayout(new MigLayout("debug"));

		lblNorth = new JLabel("Sever");
		lblEast = new JLabel("Istok");
		lblWest = new JLabel("Zapad");
		lblSouth = new JLabel("Jug");
		taCenter = new JTextArea("Neki tekst.......", 10, 30);
		btnOK = new JButton("Potvrda");
		
		add(lblNorth, "dock north");
		add(lblEast, "dock east");
		add(lblWest, "dock west");
		add(btnOK, "dock south, gapy 10px");
		add(lblSouth, "dock south");		
		add(taCenter, "dock center");		
	}

}
