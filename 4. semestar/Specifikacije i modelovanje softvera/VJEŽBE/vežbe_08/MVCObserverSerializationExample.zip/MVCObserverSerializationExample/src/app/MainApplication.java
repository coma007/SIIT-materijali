package app;

import view.MainFrame;

public class MainApplication {

	public static void main(String[] args) {
		MainFrame.getInstance();
	}

}
