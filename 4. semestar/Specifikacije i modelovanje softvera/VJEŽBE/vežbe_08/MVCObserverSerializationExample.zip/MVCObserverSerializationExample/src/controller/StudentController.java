package controller;

import repository.StudentsRepository;
import utils.BadFormatException;
import utils.MissingValueException;
import view.MainFrame;

public class StudentController {

	private StudentsRepository studentsRepository;

	public StudentController(StudentsRepository studentsRepository) {
		this.studentsRepository = studentsRepository;
	}

	public void saveStudent(long id, String name, String surname, String email, String index, String phone, String address)
			throws MissingValueException, BadFormatException {
		if (emptyValue(name)) {
			throw new MissingValueException("name");
		} else if (emptyValue(surname)) {
			throw new MissingValueException("surname");
		} else if (emptyValue(email)) {
			throw new MissingValueException("email");
		} else if (emptyValue(index)) {
			throw new MissingValueException("index");
		} else if (emptyValue(phone)) {
			throw new MissingValueException("phone");
		} else if (emptyValue(address)) {
			throw new MissingValueException("address");
		} else if (!phone.matches("[0-9]{6,10}")) {
			throw new BadFormatException("phone");
		}

		this.studentsRepository.saveStudent(id, name, surname, email, index, phone, address);

	}

	public void deleteStudent(int numberOfStudent) {
		this.studentsRepository.deleteStudent(numberOfStudent);
	}

	private boolean emptyValue(String value) {
		return value == null || value.equals("");
	}

}
