package observer;

public class RepositoryUpdateEvent {
	
	private String akcija;
	
	public RepositoryUpdateEvent() {}
	
	public RepositoryUpdateEvent(String akcija) {
		this.akcija = akcija;
	}
	
}
