package observer;

public interface Observer {
	
	public void updatePerformed(RepositoryUpdateEvent event);
	
}
