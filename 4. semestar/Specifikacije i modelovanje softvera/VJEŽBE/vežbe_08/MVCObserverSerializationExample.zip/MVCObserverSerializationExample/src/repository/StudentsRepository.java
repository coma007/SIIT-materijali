package repository;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.XStream;

import model.Student;
import observer.Observer;
import observer.Publisher;
import observer.RepositoryUpdateEvent;

public class StudentsRepository implements Publisher {

	private long generator;

	private List<Student> students;
	private List<String> columns;
	private List<Observer> observers;

	public StudentsRepository() {
		generator = 0;

		this.students = new ArrayList<Student>();
		this.deserializeStudents();

		this.columns = new ArrayList<String>();
		this.columns.add("ID");
		this.columns.add("Namee");
		this.columns.add("Surname");
		this.columns.add("Email");
		this.columns.add("Index");
	}

	private long generateId() {
		return ++generator;
	}

	public int getColumnCount() {
		return 5;
	}

	public String getColumnName(int index) {
		return this.columns.get(index);
	}

	public Student getRow(int rowIndex) {
		return this.students.get(rowIndex);
	}

	public String getValueAt(int row, int column) {
		Student student = this.students.get(row);
		switch (column) {
		case 0:
			return Long.toString(student.getId());
		case 1:
			return student.getName();
		case 2:
			return student.getSurname();
		case 3:
			return student.getEmail();
		case 4:
			return student.getIndex();
		default:
			return null;
		}
	}

	public void saveStudent(long id, String name, String surname, String email, String index, String phone,
			String address) {

		Student student = findStudentById(id);

		if (student == null) {
			student = new Student(generateId(), name, surname, email, index, phone, address);
			this.students.add(student);
		} else {
			student.setName(name);
			student.setSurname(surname);
			student.setEmail(email);
			student.setIndex(index);
			student.setPhone(phone);
			student.setAddress(address);
		}

		this.notifyObservers();
	}

	public void deleteStudent(int numberOfStudent) {
		this.students.remove(numberOfStudent);
		this.notifyObservers();
	}

	private Student findStudentById(long id) {
		Student st = null;
		for (Student s : this.students) {
			if (s.getId() == id)
				st = s;
		}
		return st;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	@Override
	public void addObserver(Observer observer) {
		if (null == observers)
			observers = new ArrayList<Observer>();
		observers.add(observer);
	}

	@Override
	public void removeObserver(Observer observer) {
		if (null == observers)
			return;
		observers.remove(observer);
	}

	@Override
	public void notifyObservers() {
		for (Observer observer : this.observers) {
			observer.updatePerformed(new RepositoryUpdateEvent());
		}
	}

	public void serializeStudents() throws IOException {
		File f = new File("students.xml");
		OutputStream os = new BufferedOutputStream(new FileOutputStream(f));
		try {

			XStream xs = new XStream();
			xs.toXML(this.students, os);

		} finally {
			os.close();
		}
	}

	private void deserializeStudents() {
		XStream xs = new XStream();

		FileReader reader;
		try {
			reader = new FileReader("students.xml");
			this.students = (ArrayList) xs.fromXML(reader);

			findLastId();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void findLastId() {
		for (Student s : this.students) {
			if (s.getId() >= this.generator)
				this.generator = s.getId();
		}
	}

}
