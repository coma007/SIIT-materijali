package view;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import controller.StudentController;

public class DeleteStudentDialog extends JDialog {

	private StudentController studentController;

	public DeleteStudentDialog(StudentController studentController, int num) {
		int dialogResult = JOptionPane.showConfirmDialog(null, "Are you sure that you want to delete student?",
				"Warning", JOptionPane.YES_NO_OPTION);
		
		if (dialogResult == JOptionPane.YES_OPTION) {
			studentController.deleteStudent(num);
			this.setVisible(false);
		}
	}

}
