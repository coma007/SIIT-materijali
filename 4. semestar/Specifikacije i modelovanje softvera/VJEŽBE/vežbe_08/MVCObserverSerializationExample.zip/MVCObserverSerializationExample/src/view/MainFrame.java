package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import controller.StudentController;
import model.Student;
import repository.StudentsRepository;

public class MainFrame extends JFrame {

	private static MainFrame instance = null;

	public static MainFrame getInstance() {
		if (instance == null) {
			instance = new MainFrame();
		}
		return instance;
	}

	private JTable studentTable;
	private StudentController studentController;
	private StudentsRepository studentsRepository;

	private MainFrame() {
		Dimension screenDimension = Toolkit.getDefaultToolkit().getScreenSize();
		setSize(screenDimension.width / 2, screenDimension.height / 2);
		setLocationRelativeTo(null);
		setTitle("Studenti");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		studentsRepository = new StudentsRepository();
		studentController = new StudentController(studentsRepository);
		studentTable = new StudentsTable(studentsRepository);
		
		initializeActions();
		
		JScrollPane scrollPane = new JScrollPane(studentTable);
		add(scrollPane, BorderLayout.CENTER);

		setVisible(true);

		// close event prilikom kog ce biti odradjena serijalizacija
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				try {
					studentsRepository.serializeStudents();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
	}

	private void initializeActions() {
		JPanel panelTop = new JPanel();
		JButton btnAdd = new JButton("Add");
		JButton btnEdit = new JButton("Edit");
		JButton btnDelete = new JButton("Delete");

		btnEdit.setEnabled(false);

		panelTop.add(btnAdd);
		panelTop.add(btnEdit);
		panelTop.add(btnDelete);

		this.add(panelTop, BorderLayout.NORTH);

		btnAdd.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				AddEditStudentDialog addEditStudentDialog = new AddEditStudentDialog(studentController, null);
			}
		});

		btnEdit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Student student = studentsRepository.getRow(studentTable.getSelectedRow());
				AddEditStudentDialog addEditStudentDialog = new AddEditStudentDialog(studentController, student);
			}
		});

		btnDelete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				DeleteStudentDialog deleteStudentDialog = new DeleteStudentDialog(studentController,
						studentTable.getSelectedRow());
			}
		});

		studentTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent event) {
				if (studentTable.getSelectedRow() > -1) {
					btnEdit.setEnabled(true);
				}
			}
		});
	}

	public JTable getStudentsTable() {
		return this.studentTable;
	}

}
