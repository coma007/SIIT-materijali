package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.StudentController;
import model.Student;
import net.miginfocom.swing.MigLayout;
import utils.BadFormatException;
import utils.MissingValueException;

public class AddEditStudentDialog extends JDialog {

	private StudentController studentController;
	private Student student;
	private long studentId;

	private JLabel lblName;
	private JTextField tfName;
	private JLabel lblSurname;
	private JTextField tfSurname;
	private JLabel lblEmail;
	private JTextField tfEmail;
	private JLabel lblIndex;
	private JTextField tfIndex;
	private JLabel lblPhone;
	private JTextField tfPhone;
	private JLabel lblAddress;
	private JTextField tfAddress;

	private JButton btnSave;
	private JButton btnCancel;

	public AddEditStudentDialog(StudentController studentController, Student student) {
		super();
		setSize(320, 260);
		setLocationRelativeTo(null);
		setTitle("Add new student");

		studentId = -1;

		this.studentController = studentController;

		setLayout(new MigLayout());

		lblName = new JLabel("Name");
		tfName = new JTextField(30);

		lblSurname = new JLabel("Surname");
		tfSurname = new JTextField(30);

		lblEmail = new JLabel("Email address");
		tfEmail = new JTextField(30);

		lblIndex = new JLabel("Index");
		tfIndex = new JTextField(30);

		lblPhone = new JLabel("Phone number");
		tfPhone = new JTextField(30);

		lblAddress = new JLabel("Address");
		tfAddress = new JTextField(30);

		if (student != null) {
			setTitle("Edit student");

			studentId = student.getId();

			tfName.setText(student.getName());
			tfSurname.setText(student.getSurname());
			tfEmail.setText(student.getEmail());
			tfIndex.setText(student.getIndex());
			tfPhone.setText(student.getPhone());
			tfAddress.setText(student.getAddress());
		}

		btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				saveStudent();
			}
		});

		btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				cancel();
			}
		});

		add(lblName);
		add(tfName, "wrap");
		add(lblSurname);
		add(tfSurname, "wrap");
		add(lblEmail);
		add(tfEmail, "wrap");
		add(lblIndex);
		add(tfIndex, "wrap");
		add(lblPhone);
		add(tfPhone, "wrap");
		add(lblAddress);
		add(tfAddress, "wrap");
		add(btnSave);
		add(btnCancel);

		this.setVisible(true);
	}

	private void saveStudent() {
		try {
			studentController.saveStudent(studentId, getName(), getSurname(), getEmail(), getIndex(), getPhone(),
					getAddress());
		} catch (MissingValueException e) {
			JOptionPane.showMessageDialog(this, "Field " + e.getValueName() + " can not be empty!", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		} catch (BadFormatException e) {
			if (e.getValueName().equals("phone")) {
				JOptionPane.showMessageDialog(this, "Phone number can contains only digits!", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
			return;
		}

		JOptionPane.showMessageDialog(this, "Student is successfully saved!", "Information",
				JOptionPane.INFORMATION_MESSAGE);

		this.setVisible(false);
	}

	private void cancel() {
		int dialogResult = JOptionPane.showConfirmDialog(this, "Are you sure you want to cancel?",
				"Canceling operation", JOptionPane.YES_NO_OPTION);

		if (dialogResult == JOptionPane.YES_OPTION) {
			this.setVisible(false);
		}
	}

	public String getName() {
		return this.tfName.getText();
	}

	private String getSurname() {
		return this.tfSurname.getText();
	}

	private String getEmail() {
		return this.tfEmail.getText();
	}

	private String getIndex() {
		return this.tfIndex.getText();
	}

	private String getPhone() {
		return this.tfPhone.getText();
	}

	private String getAddress() {
		return this.tfAddress.getText();
	}

}
