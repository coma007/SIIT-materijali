package view;

import javax.swing.table.AbstractTableModel;

import repository.StudentsRepository;

public class AbstractTableModelStudents extends AbstractTableModel {

	private StudentsRepository studentsRepository;

	public AbstractTableModelStudents(StudentsRepository studentsRepository) {
		this.studentsRepository = studentsRepository;
	}

	@Override
	public int getRowCount() {
		return studentsRepository.getStudents().size();
	}

	@Override
	public int getColumnCount() {
		return studentsRepository.getColumnCount();
	}

	@Override
	public String getColumnName(int column) {
		return studentsRepository.getColumnName(column);
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return studentsRepository.getValueAt(rowIndex, columnIndex);
	}

	public StudentsRepository getStudentsRepository() {
		return this.studentsRepository;
	}
}
