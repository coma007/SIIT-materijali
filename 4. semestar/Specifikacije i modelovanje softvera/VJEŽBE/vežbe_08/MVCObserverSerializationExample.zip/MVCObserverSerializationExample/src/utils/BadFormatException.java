package utils;

public class BadFormatException extends Exception {
	
	private String valueName;
	
	public BadFormatException(String valueName) {
		this.valueName = valueName;
	}
	
	public String getValueName() {
		return valueName;
	}
}
