/**
 * 
 */
package file;

import java.io.File;

/**
 * @author Danijel
 *
 */
public class FilePrimer {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// preporuka je uvek koristiti relativnu putanju
		File f1 = new File("test.txt");
		System.out.println(String.format("Aspolutna putanja: %s", f1.getAbsolutePath()));
		System.out.println(String.format("Relativna putanja: %s", f1.getPath()));
		
		// Nikada ne navoditi separator putanje koji je zavisan 
		// od tipa datoteckog sistema, odnosno OS-a.
		// Umesto toga koristiti sledece: 
		System.out.println("Separator putanje na ovoj platformi je: " + File.separator);
		File f2 = new File("images" + File.separator + "test.jpg");
		System.out.println(String.format("Aspolutna putanja: %s", f2.getAbsolutePath()));
		System.out.println(String.format("Relativna putanja: %s", f2.getAbsolutePath()));

		File parentDir = new File("test-parent");
		// direktorijum koji treba relativno pozicionirati u odnosu na roditeljski direktorijum
		File childDir = new File(parentDir, "test-child");
		System.out.println(String.format("Aspolutna putanja: %s", childDir.getAbsolutePath()));

		File src = new File("src");
		File[] files = src.listFiles();
		// sadrzaj direktorijuma "src"
		for (File f : files) {
			System.out.println("  " + f + " " + f.isDirectory() + " " + f.isFile());
		}

	}

}
