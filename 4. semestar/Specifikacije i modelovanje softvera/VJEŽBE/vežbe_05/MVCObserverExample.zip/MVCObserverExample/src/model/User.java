package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import observer.Observer;
import observer.ProfileUpdateEvent;
import observer.Publisher;

public class User implements Publisher {
	
	private String name;
	private String surname;
	private String username;
	private LocalDate dateOfBirth;
	
	private List<Observer> observers;
	
	public User() {}

	public User(String name, String surname, String username, LocalDate dateOfBirth) {
		super();
		this.name = name;
		this.surname = surname;
		this.username = username;
		this.dateOfBirth = dateOfBirth;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public void updateProfile(String name, String surname, String username, LocalDate dateOfBirth) {
		setName(name);
		setSurname(surname);
		setUsername(username);
		setDateOfBirth(dateOfBirth);
		notifyObservers();
	}

	@Override
	public void addObserver(Observer observer) {
		if (null == observers)
			observers = new ArrayList<Observer>();
		observers.add(observer);	
	}

	@Override
	public void removeObserver(Observer observer) {
		if (null == observers)
			return;
		observers.remove(observer);
	}

	@Override
	public void notifyObservers() {
		ProfileUpdateEvent e = new ProfileUpdateEvent(this.getName(), this.getSurname(), this.getUsername(), this.getDateOfBirth().toString());
		for (Observer observer : observers) {
			observer.updatePerformed(e);
		}	
	}

}
