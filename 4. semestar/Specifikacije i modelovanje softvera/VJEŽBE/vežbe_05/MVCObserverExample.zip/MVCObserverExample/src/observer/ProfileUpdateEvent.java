package observer;

import java.util.EventObject;

public class ProfileUpdateEvent extends EventObject {

	private String name;
	private String surname;
	private String username;
	private String dateOfBirth;
	
	public ProfileUpdateEvent(String name, String surname, String username, String dateOfBirth) {
		super(name);
		this.name = name;
		this.surname = surname;
		this.username = username;
		this.dateOfBirth = dateOfBirth;
	}

	public String getName() {
		return name;
	}

	public String getSurname() {
		return surname;
	}

	public String getUsername() {
		return username;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}
	
}
