package observer;

public interface Observer {
	
	public void updatePerformed(ProfileUpdateEvent e);
	
}
