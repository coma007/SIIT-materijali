package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.User;
import observer.Observer;
import observer.ProfileUpdateEvent;

public class ProfileView extends JPanel implements Observer {

	private User user;
    
    // private JLabel showUser;
	
	private JTextField tfName;
	private JLabel lblName;
	private JTextField tfSurname;
	private JLabel lblSurname;
	private JTextField tfUsername;
	private JLabel lblUsername;
	private JTextField tfDateOfBirth;
	private JLabel lblDateOfBirth;
	
	public ProfileView(User user) {
		setVisible(true);
		setBackground(new Color(150, 143, 255));
		
		this.user = user;
		this.user.addObserver(this);
		
		Font font = new Font("SansSerif",Font.BOLD, 16);
		
		lblName = new JLabel("Name: ");
		lblName.setPreferredSize(new Dimension(130,30));
		lblName.setFont(font);
		tfName = new JTextField();
		tfName.setText(user.getName());
		tfName.setPreferredSize(new Dimension(320, 40));
		tfName.setEditable(false);
		JPanel pnlName = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlName.add(Box.createHorizontalStrut(10));
		pnlName.add(lblName);
		pnlName.add(tfName);
		
		lblSurname = new JLabel("Surname: ");
		lblSurname.setPreferredSize(new Dimension(130,30));
		lblSurname.setFont(font);
		tfSurname = new JTextField();
		tfSurname.setText(user.getSurname());
		tfSurname.setPreferredSize(new Dimension(320, 40));
		tfSurname.setEditable(false);
		JPanel pnlSurname = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlSurname.add(Box.createHorizontalStrut(10));
		pnlSurname.add(lblSurname);
		pnlSurname.add(tfSurname);
		
		lblUsername = new JLabel("Username: ");
		lblUsername.setPreferredSize(new Dimension(130,30));
		lblUsername.setFont(font);
		tfUsername = new JTextField();
		tfUsername.setText(user.getUsername());
		tfUsername.setPreferredSize(new Dimension(320, 40));
		tfUsername.setEditable(false);
		JPanel pnlUsername = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlUsername.add(Box.createHorizontalStrut(10));
		pnlUsername.add(lblUsername);
		pnlUsername.add(tfUsername);
		
		lblDateOfBirth = new JLabel("Date of birth: ");
		lblDateOfBirth.setPreferredSize(new Dimension(130,30));
		lblDateOfBirth.setFont(font);
		tfDateOfBirth = new JTextField();
		tfDateOfBirth.setText(user.getDateOfBirth().toString());
		tfDateOfBirth.setPreferredSize(new Dimension(320, 40));
		tfDateOfBirth.setEditable(false);
		JPanel pnlDateOfBirth = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlDateOfBirth.add(Box.createHorizontalStrut(10));
		pnlDateOfBirth.add(lblDateOfBirth);
		pnlDateOfBirth.add(tfDateOfBirth);
		
		Box box = Box.createVerticalBox();
		box.add(Box.createVerticalStrut(10));
		box.add(pnlName);
		box.add(pnlSurname);
		box.add(pnlUsername);
		box.add(pnlDateOfBirth);
		
		JPanel centerPanel = new JPanel(new BorderLayout());
		centerPanel.add(box, BorderLayout.CENTER);
		
		add(centerPanel);
	}
	
	private void updateProfileView(String name, String surname, String username, String dateOfBirth) {
		tfName.setText(name);
		tfSurname.setText(surname);
		tfUsername.setText(username);
		tfDateOfBirth.setText(dateOfBirth);
	}
	
	@Override
	public void updatePerformed(ProfileUpdateEvent e) {
		updateProfileView(e.getName(), e.getSurname(), e.getUsername(), e.getDateOfBirth());
		repaint();
	}
	
}
