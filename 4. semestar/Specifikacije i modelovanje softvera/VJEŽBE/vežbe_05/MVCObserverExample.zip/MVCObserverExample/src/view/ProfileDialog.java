package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeParseException;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.UserController;
import model.User;
import utils.MissingValueException;

public class ProfileDialog extends JDialog {
	
	private User userModel;
	private UserController userController;
	
	private JTextField tfName;
	private JLabel lblName;
	private JTextField tfSurname;
	private JLabel lblSurname;
	private JTextField tfUsername;
	private JLabel lblUsername;
	private JTextField tfDateOfBirth;
	private JLabel lblDateOfBirth;
	
	private JButton btnEdit;
	
	public ProfileDialog(User user, UserController userController) {
		super();
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Edit user profile");
		
		this.userModel = user;
		this.userController = userController;
		
		JPanel pnlProfile = new JPanel(new BorderLayout());
		
		Font font = new Font("SansSerif",Font.PLAIN, 16);
		
		lblName = new JLabel("Name: ");
		lblName.setPreferredSize(new Dimension(100,30));
		tfName = new JTextField();
		tfName.setText(userModel.getName());
		tfName.setPreferredSize(new Dimension(320, 40));
		JPanel pnlName = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlName.add(Box.createHorizontalStrut(10));
		pnlName.add(lblName);
		pnlName.add(tfName);
		
		lblSurname = new JLabel("Surname: ");
		lblSurname.setPreferredSize(new Dimension(100,30));
		tfSurname = new JTextField();
		tfSurname.setText(userModel.getSurname());
		tfSurname.setPreferredSize(new Dimension(320, 40));
		JPanel pnlSurname = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlSurname.add(Box.createHorizontalStrut(10));
		pnlSurname.add(lblSurname);
		pnlSurname.add(tfSurname);
		
		lblUsername = new JLabel("Username: ");
		lblUsername.setPreferredSize(new Dimension(100,30));
		tfUsername = new JTextField();
		tfUsername.setText(userModel.getUsername());
		tfUsername.setPreferredSize(new Dimension(320, 40));
		JPanel pnlUsername = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlUsername.add(Box.createHorizontalStrut(10));
		pnlUsername.add(lblUsername);
		pnlUsername.add(tfUsername);
		
		lblDateOfBirth = new JLabel("Date of birth: ");
		lblDateOfBirth.setPreferredSize(new Dimension(100,30));
		tfDateOfBirth = new JTextField();
		tfDateOfBirth.setText(userModel.getDateOfBirth().toString());
		tfDateOfBirth.setPreferredSize(new Dimension(320, 40));
		JPanel pnlDateOfBirth = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlDateOfBirth.add(Box.createHorizontalStrut(10));
		pnlDateOfBirth.add(lblDateOfBirth);
		pnlDateOfBirth.add(tfDateOfBirth);
		
		Box box = Box.createVerticalBox();
		JLabel lblHeader = new JLabel("Make changes to your profile");
		lblHeader.setFont(font);
		box.add(lblHeader);
		box.add(Box.createVerticalStrut(10));
		box.add(pnlName);
		box.add(pnlSurname);
		box.add(pnlUsername);
		box.add(pnlDateOfBirth);
		
		pnlProfile.add(box, BorderLayout.CENTER);
		
		btnEdit = new JButton("Make changes");
		btnEdit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				makeProfileChanges();
			}
		});
		pnlProfile.add(btnEdit, BorderLayout.SOUTH);
		
		add(pnlProfile);
	}
	
	private void makeProfileChanges() {
		try {
			userController.makeProfileChanges(getNameText(), getSurnameText(), getUsernameText(), getDateOfBirthText());
		}
		catch (MissingValueException e) {
			if (e.getValueName().equals("name")) {
				JOptionPane.showMessageDialog(this, "Name is not entered!", "Error", JOptionPane.ERROR_MESSAGE);
			}
			else if(e.getValueName().equals("surname")) {
				JOptionPane.showMessageDialog(this, "Surname is not entered!", "Error", JOptionPane.ERROR_MESSAGE);
			}
			else if(e.getValueName().equals("username")) {
				JOptionPane.showMessageDialog(this, "Username is not entered!", "Error", JOptionPane.ERROR_MESSAGE);
			}
			else if(e.getValueName().equals("dateOfBirth")) {
				JOptionPane.showMessageDialog(this, "Date of birth is not entered!", "Error", JOptionPane.ERROR_MESSAGE);
			}
		} catch (DateTimeParseException e) {
			JOptionPane.showMessageDialog(this, "Entered date is not in valid format. Required format is yyyy-mm-dd!",
					"Error", JOptionPane.ERROR_MESSAGE);
		}
		
		this.setVisible(false);
	}
	
	private String getNameText() {
		return this.tfName.getText();
	}
	
	private String getSurnameText() {
		return this.tfSurname.getText();
	}
	
	private String getUsernameText() {
		return this.tfUsername.getText();
	}
	
	private String getDateOfBirthText() {
		return this.tfDateOfBirth.getText();
	}
	
}
