package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;

import controller.UserController;
import model.User;

public class MainFrame extends JFrame {
	
	private JButton btnProfile;
	private ProfileView profileView;
	
	public MainFrame() {
		super();
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		setSize(screenWidth, screenHeight);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setTitle("User profile");
		
		User user = new User("Milan", "Milic", "Miki123", LocalDate.parse("1995-08-16"));
		UserController userController = new UserController(user);
		
		profileView = new ProfileView(user);
		add(profileView, BorderLayout.CENTER);
		
		btnProfile = new JButton("Edit your profile");
		btnProfile.setPreferredSize(new Dimension(300, 50));
		btnProfile.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ProfileDialog profileDialog = new ProfileDialog(user, userController);
				profileDialog.setVisible(true);
			}
		});
		
		add(btnProfile, BorderLayout.SOUTH);
	}
	
}
