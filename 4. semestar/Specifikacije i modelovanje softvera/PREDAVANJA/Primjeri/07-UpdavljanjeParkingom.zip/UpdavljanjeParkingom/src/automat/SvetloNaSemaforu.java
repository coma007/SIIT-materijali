package automat;

public enum SvetloNaSemaforu {	
	CRVENO, ZELENO
}

