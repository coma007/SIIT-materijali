 function printSth(){
    console.log("I AM PRINT SOMETHING FUNCTION FROM script2.js FILE");
}