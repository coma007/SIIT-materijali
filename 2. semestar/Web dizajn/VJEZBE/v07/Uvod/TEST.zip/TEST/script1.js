

callPrintSth();

function callPrintSth() {
    console.log('CALL PRINT SOMETHING');
    printSth();
}
