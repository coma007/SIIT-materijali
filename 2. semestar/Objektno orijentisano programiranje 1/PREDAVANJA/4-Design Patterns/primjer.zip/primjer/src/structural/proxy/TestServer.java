package structural.proxy;

import java.net.ServerSocket;
import java.net.Socket;

import structural.proxy.server.LoginServiceImpl;
import structural.proxy.server.ProxyReceiver;

public class TestServer {
	public static void main(String[] args) {
		// sa serverske strane
		LoginService serverskiObjekat = new LoginServiceImpl();
		ServerSocket ss;
		try {
			ss = new ServerSocket(9000);
			while (true) {
				System.out.println("SERVER CEKA KLIJENTA");
				Socket s = ss.accept();
				((ProxyReceiver)serverskiObjekat).executeCommand(s);
				s.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
