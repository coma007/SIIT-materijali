package structural.adapter.byinheritance;

public class Racunar {
	USBTastatura tastatura;
	
	public void testTastature() {
		System.out.println(tastatura.vratiTaster());
	}
}
