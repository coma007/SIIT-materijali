package structural.proxy;

public interface LoginService {
	public boolean login(String username, String password) throws Exception;
}
