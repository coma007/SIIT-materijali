package structural.adapter.bycomposition;

public class PS2Tastatura {
	public int vratiTaster() {
		System.out.println("PS2 tastatura vraća taster.");
		return 65;
	}
}
