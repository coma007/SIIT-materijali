package structural.proxy;

import structural.proxy.client.LoginServiceProxy;

public class TestClient {

	public static void main(String[] args) {
		// sa klijentske strane
		try {
			LoginService proxy = new LoginServiceProxy();
			System.out.println(proxy.login("pera", "pera"));
			System.out.println(proxy.login("mika", "mika"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
