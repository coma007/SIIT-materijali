package structural.adapter.byinheritance;

public interface USBTastatura {
	public int vratiTaster();
}
