package structural.proxy.server;

import structural.proxy.LoginService;

/** Kompleksni objekat, na serverskoj strani. Pravi ga programer na osnovu LoginService interfejsa. */
public class LoginServiceImpl extends ProxyReceiver implements LoginService {

	@Override
	public boolean login(String username, String password)  throws Exception {
		System.out.println("REMOTE LOGIN, USERNAME: " + username + ", PASSWORD: " + password);
		if (username.equals("pera") && password.equals("pera"))
			return true;
		else
			return false;
	}

}
