package structural.facade;

public class Memorija {
	public void ucitajBootSektor(byte boot[]) {
		System.out.println("MEM: ucitao boot sektor sa diska");
	}
}
