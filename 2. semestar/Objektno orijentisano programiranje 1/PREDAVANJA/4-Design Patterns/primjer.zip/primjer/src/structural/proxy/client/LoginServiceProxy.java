package structural.proxy.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import structural.proxy.LoginService;
import structural.proxy.server.ProxyReceiver;

/** Masinski generisana klasa na osnovu LoginService interfejsa. */
public class LoginServiceProxy implements LoginService {

	@Override
	public boolean login(String username, String password) throws Exception {
		Socket socket = new Socket("localhost", 9000);
		BufferedReader in = new BufferedReader(new InputStreamReader(
				socket.getInputStream()));
		PrintWriter out = new PrintWriter(new OutputStreamWriter(
				socket.getOutputStream()), true);

		System.out.println("LOCAL LOGIN, USERNAME: " + username
				+ ", PASSWORD: " + password);
		
		String command = "" + ProxyReceiver.LOGIN;
		out.println(command);
		System.out.println("POSLAO KOMANDU: " + command);
		out.println(username);
		System.out.println("POSLAO USERNAME: " + username);
		out.println(password);
		System.out.println("POSLAO PASSWORD: " + password + ", CEKAM ODGOVOR");

		String res = in.readLine();
		System.out.println("DOBIO ODGOVOR: " + res);

		in.close();
		out.close();
		socket.close();
		return Boolean.parseBoolean(res);
	}

}
