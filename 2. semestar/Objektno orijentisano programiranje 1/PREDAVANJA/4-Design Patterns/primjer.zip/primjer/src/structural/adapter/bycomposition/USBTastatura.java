package structural.adapter.bycomposition;

public interface USBTastatura {
	public int vratiTaster();
}
