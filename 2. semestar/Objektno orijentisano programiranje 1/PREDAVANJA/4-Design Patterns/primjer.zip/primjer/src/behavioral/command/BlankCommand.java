package behavioral.command;

public class BlankCommand extends Command {

	@Override
	public boolean execute() {
		return true;
	}

}
