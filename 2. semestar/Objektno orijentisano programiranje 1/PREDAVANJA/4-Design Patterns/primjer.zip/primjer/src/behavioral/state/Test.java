package behavioral.state;

public class Test {

	public static void main(String[] args) {
		Semafor semafor = new Semafor();
		semafor.ukljuci();
	}

}
