package behavioral.obsever;

public interface Observer {
	public void update(int newState);
}
