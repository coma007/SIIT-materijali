package behavioral.chainofresponsibility;

public interface MozeDaPotpise {
	public void potpisi(Zahtev z);
}
