package creational.abstractfactory;

public abstract class Vozilo {
	public abstract void vozi();
}
