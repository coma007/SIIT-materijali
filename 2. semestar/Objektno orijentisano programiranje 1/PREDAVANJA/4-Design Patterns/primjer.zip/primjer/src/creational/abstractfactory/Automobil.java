package creational.abstractfactory;

public class Automobil extends Vozilo {

	@Override
	public void vozi() {
		System.out.println("Vozimo automobil.");
	}

}
