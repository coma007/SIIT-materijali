package creational.abstractfactory;

public class Kamion extends Vozilo {

	@Override
	public void vozi() {
		System.out.println("Vozimo kamion.");
	}

}
