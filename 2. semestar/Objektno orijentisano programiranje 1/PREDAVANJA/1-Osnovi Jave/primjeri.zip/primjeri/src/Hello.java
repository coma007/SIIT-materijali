
public class Hello {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder(100000);
		for (int i = 0; i < 100000; i++) {
			sb.append("a");
		}
		System.out.println(sb.length());
 		
//		String p = "";
//		for (int i = 0; i < 100000; i++) {
//			p += "a";
//		}
//		System.out.println(p.length());
		
		// TODO Auto-generated method stub
//		System.out.println("Hello");
//		int a[] = {1,2,3};
//		int b = a[2];
//		System.out.println(b);
//		System.out.println("Duzina niza je: " + a.length);
//		
//		String s = "Ja sam svetski mega car!";
//		System.out.println(s);
//		System.out.println("Duzina stringa s je: " + s.length());
//		String s1 = "pera";
//		String s2 = "pera";
//		
//		System.out.println(s2 == s1);
		
		float f = 100000.0f;
		short i = (short) f;
		System.out.println(i);
	}

}
