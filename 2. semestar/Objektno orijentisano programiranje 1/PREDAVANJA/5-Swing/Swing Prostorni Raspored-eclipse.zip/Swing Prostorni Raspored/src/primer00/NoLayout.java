package primer00;

import javax.swing.JButton;
import javax.swing.JFrame;

public class NoLayout extends JFrame {
	private static final long serialVersionUID = 7191936660027249340L;

	public NoLayout() {
		setSize(640, 480);
		// Postaviti Layout na null
		setLayout(null); 
		setResizable(false);
		JButton ok = new JButton("Ok"); 
		getContentPane().add(ok); 
		// Postaviti komponente direktno na koordinate
		ok.setBounds(100, 100, 50, 30);
		setVisible(true);
	}

	public static void main(String[] args) {
		new NoLayout();
	}

}
