package primer02;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class DijalogFrame extends JFrame {
	public DijalogFrame() {
		setSize(400, 300);
		setTitle("Primer");
		
		FlowLayout f = new FlowLayout(FlowLayout.RIGHT);
		JPanel p = new JPanel();
		p.setLayout(f);
		JButton btnOK = new JButton("OK");
		JButton btnCancel = new JButton("Cancel");
		p.add(btnOK);
		p.add(btnCancel);
		
		getContentPane().add(p, BorderLayout.SOUTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new DijalogFrame();

	}

}
