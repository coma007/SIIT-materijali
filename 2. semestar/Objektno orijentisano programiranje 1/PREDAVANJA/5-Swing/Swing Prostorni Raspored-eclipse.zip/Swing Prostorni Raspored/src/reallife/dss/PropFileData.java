package reallife.dss;

public class PropFileData {
	public String scriptsPath;
	public String MW_Url;
	public String templateExcludeList;
	public String cluster;
}
