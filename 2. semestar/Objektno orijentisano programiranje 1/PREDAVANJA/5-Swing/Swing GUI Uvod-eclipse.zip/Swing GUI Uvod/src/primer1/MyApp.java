package primer1;

public class MyApp {
  public static void main(String[] args) {
    new MainFrame();
  }
}