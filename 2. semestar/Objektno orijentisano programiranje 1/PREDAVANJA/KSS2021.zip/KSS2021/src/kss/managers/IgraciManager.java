package kss.managers;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import kss.model.Igrac;
import kss.model.Klub;

public class IgraciManager {
	private List<Igrac> igraci;
	private KluboviManager km;

	public IgraciManager(String file, KluboviManager km) {
		this.igraci = new ArrayList<Igrac>();
		this.km = km;
		
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "utf-8"));
			String line;
			while((line = in.readLine()) != null) {
				line = line.trim();
				if (line.equals("") || line.startsWith("#"))
					continue;
				//System.out.println(line);
				Igrac i = parse(line);
				this.igraci.add(i);
			}
			in.close();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		
	}

	private Igrac parse(String line) {
		// ID; Ime; Prezime; ID_Kluba
		String[] tokens = line.split(";");
		int id = Integer.parseInt(tokens[0].trim());
		String ime = tokens[1].trim();
		String prezime = tokens[2].trim();
		int klubId = Integer.parseInt(tokens[3].trim());
		Klub k = this.km.getKluboviMap().get(klubId);
		Igrac ret = new Igrac(id, ime, prezime, k);
		k.getIgraci().add(ret);
		return ret;
	}

	public List<Igrac> getIgraci() {
		return this.igraci;
	}
}
