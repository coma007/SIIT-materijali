package kss.gui.klubovi;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import kss.managers.KluboviManager;
import kss.model.Klub;

public class KluboviModel extends AbstractTableModel {

	private static final long serialVersionUID = -365797867123809469L;
	
	private String[] kolone = {"Id", "Naziv"};
	private List<Klub> klubovi;

	public KluboviModel(KluboviManager km) {
		this.klubovi = km.getKlubovi();
	}
	
	@Override
	public int getRowCount() {
		return this.klubovi.size();
	}

	@Override
	public int getColumnCount() {
		return this.kolone.length;
	}

	@Override
	public String getColumnName(int col) {
		return this.kolone[col];
	}
	
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Klub k = this.klubovi.get(rowIndex);
		return k.toCell(columnIndex);
	}
	

}
