package kss.gui.igraci;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import kss.managers.KluboviManager;
import kss.model.Igrac;
import kss.model.Klub;

public class EditIgracDlg extends JDialog {

	private static final long serialVersionUID = 7728457178687575633L;
	private Igrac igrac;
	private JTextField txtIme;
	private JTextField txtPrezime;
	private JComboBox<Klub> cmbKlub;
	private boolean nov;

	private boolean odustao;

	public EditIgracDlg(FrmIgraci parent, KluboviManager km) {
		super(parent, true);

		setSize(600, 400);
		setTitle("Podaci o igraÄ�u");
		
		JPanel pnlButtons = new JPanel();
		getContentPane().add(pnlButtons, BorderLayout.SOUTH);

		JButton btnSave = new JButton("Snimi");
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (prazan()) {
					JOptionPane.showMessageDialog(parent, "Niste popunili sva tri polja!");
					return;
				}

				igrac.setIme(txtIme.getText());
				igrac.setPrezime(txtPrezime.getText());
				Klub k = (Klub) cmbKlub.getSelectedItem();

				if (nov == false) {
					// ako editujemo postojeÄ‡eg igraÄ�a
					igrac.getKlub().getIgraci().remove(igrac);
				}
				igrac.setKlub(k);
				igrac.getKlub().getIgraci().add(igrac);
				odustao = false;

				setVisible(false);
			}
		});

		pnlButtons.add(btnSave);

		JButton btnCancel = new JButton("Odustani");
		btnCancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// editujemo postojeÄ‡eg
				/*
				 * Umesto da ovde proveravamo da li je igraÄ� promenjen, to Ä‡emo proveriti u
				 * metodi processWindowEvent (pogledajte skroz dole).
				 */
//				if (promenjeno()) {
//					if (JOptionPane.showConfirmDialog(parent,
//							"IgraÄ� je izmenjen. Da li ipak Å¾elite da izaÄ‘ete?") == JOptionPane.YES_OPTION) {
//						setVisible(false);
//					}
//				} else {
//				setVisible(false);
//				}
				// Umesto setVisible(true), uradiÄ‡emo ovo dole,
				// da bi se aktivirao WindowClosing dogaÄ‘aj
				// (pogledajte skroz dole).
				dispatchEvent(new WindowEvent(EditIgracDlg.this, WindowEvent.WINDOW_CLOSING));
			}
		});
		pnlButtons.add(btnCancel);

		JPanel panel = new JPanel();

		getContentPane().add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] { 0, 0, 0 };
		gbl_panel.rowHeights = new int[] { 0, 0, 0, 0 };
		gbl_panel.columnWeights = new double[] { 1.0, 1.0, Double.MIN_VALUE };
		gbl_panel.rowWeights = new double[] { 0.0, 0.0, 0.0, Double.MIN_VALUE };
		panel.setLayout(gbl_panel);

		JLabel lblIme = new JLabel("Ime:");
		GridBagConstraints gbc_lblIme = new GridBagConstraints();
		gbc_lblIme.anchor = GridBagConstraints.EAST;
		gbc_lblIme.insets = new Insets(0, 0, 5, 5);
		gbc_lblIme.gridx = 0;
		gbc_lblIme.gridy = 0;
		panel.add(lblIme, gbc_lblIme);

		txtIme = new JTextField();
		GridBagConstraints gbc_txtIme = new GridBagConstraints();
		gbc_txtIme.insets = new Insets(0, 0, 5, 0);
		gbc_txtIme.weightx = 2.0;
		gbc_txtIme.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtIme.gridx = 1;
		gbc_txtIme.gridy = 0;
		panel.add(txtIme, gbc_txtIme);
		txtIme.setColumns(10);

		JLabel lblPrezime = new JLabel("Prezime:");
		GridBagConstraints gbc_lblPrezime = new GridBagConstraints();
		gbc_lblPrezime.anchor = GridBagConstraints.EAST;
		gbc_lblPrezime.insets = new Insets(0, 0, 5, 5);
		gbc_lblPrezime.gridx = 0;
		gbc_lblPrezime.gridy = 1;
		panel.add(lblPrezime, gbc_lblPrezime);

		txtPrezime = new JTextField();
		GridBagConstraints gbc_txtPrezime = new GridBagConstraints();
		gbc_txtPrezime.insets = new Insets(0, 0, 5, 0);
		gbc_txtPrezime.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtPrezime.gridx = 1;
		gbc_txtPrezime.gridy = 1;
		panel.add(txtPrezime, gbc_txtPrezime);
		txtPrezime.setColumns(10);

		JLabel lblKlub = new JLabel("Klub:");
		GridBagConstraints gbc_lblKlub = new GridBagConstraints();
		gbc_lblKlub.anchor = GridBagConstraints.EAST;
		gbc_lblKlub.insets = new Insets(0, 0, 0, 5);
		gbc_lblKlub.gridx = 0;
		gbc_lblKlub.gridy = 2;
		panel.add(lblKlub, gbc_lblKlub);

		cmbKlub = new JComboBox<Klub>();
		GridBagConstraints gbc_cmbKlub = new GridBagConstraints();
		gbc_cmbKlub.fill = GridBagConstraints.HORIZONTAL;
		gbc_cmbKlub.gridx = 1;
		gbc_cmbKlub.gridy = 2;

		for (Klub k : km.getKlubovi()) {
			cmbKlub.addItem(k);
		}

		panel.add(cmbKlub, gbc_cmbKlub);
	}

	private boolean prazan() {
		if (txtIme.getText().equals("") || txtPrezime.getText().equals("") || cmbKlub.getSelectedItem() == null)
			return true;
		else
			return false;
	}

	private boolean promenjeno() {
		if (!igrac.getIme().equals(txtIme.getText()) || !igrac.getPrezime().equals(txtPrezime.getText())
				|| igrac.getKlub() != cmbKlub.getSelectedItem())
			return true;
		else
			return false;
	}

	public void setIgrac(Igrac i, boolean nov) {
		this.nov = nov;
		this.odustao = true;

		this.igrac = i;
		this.txtIme.setText(i.getIme());
		this.txtPrezime.setText(i.getPrezime());
		this.cmbKlub.setSelectedItem(i.getKlub());
	}

	public boolean isOdustao() {
		return this.odustao;
	}

	@Override
	protected void processWindowEvent(WindowEvent e) {
		if (e.getID() == WindowEvent.WINDOW_CLOSING) {
				int opt = JOptionPane.showConfirmDialog(null, "IgraÄ� je izmenjen. Da li ipak Å¾elite da izaÄ‘ete?",
						"Potvrdite", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				if (opt == JOptionPane.NO_OPTION || opt == JOptionPane.CLOSED_OPTION) {
					return;
				}
				super.processWindowEvent(e);
			} else {
				super.processWindowEvent(e);
			}
		}

		super.processWindowEvent(e);
	}

}
