package kss.gui.igraci;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import kss.managers.IgraciManager;
import kss.model.Igrac;

public class IgraciModel extends AbstractTableModel {

	private static final long serialVersionUID = 6579243965615046676L;
	private String[] kolone = {"Id", "Ime", "Prezime", "Klub"};
	List<Igrac> igraci;

	public IgraciModel(IgraciManager im) {
		this.igraci = im.getIgraci();
	}

	@Override
	public int getRowCount() {
		return igraci.size();
	}

	@Override
	public int getColumnCount() {
		return kolone.length;
	}
	
	@Override
	public String getColumnName(int col) {
		return this.kolone[col];
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Igrac i = this.igraci.get(rowIndex);
		return i.toCell(columnIndex);
	}

}
