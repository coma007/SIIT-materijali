package kss.gui.klubovi;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import kss.managers.KluboviManager;

public class FrmKlubovi extends JFrame {

	private static final long serialVersionUID = 8918081107182634910L;
	
	public FrmKlubovi(KluboviManager km) {
		
		JTable tblKlubovi = new JTable(new KluboviModel(km));
		JScrollPane scr = new JScrollPane(tblKlubovi);
		getContentPane().add(scr, BorderLayout.CENTER);
		
		JPanel pnlButtons = new JPanel();
		JButton btnZatvori = new JButton("Zatvori");
		btnZatvori.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		pnlButtons.add(btnZatvori);
		
		getContentPane().add(pnlButtons, BorderLayout.SOUTH);
		
		setSize(800, 600);
		setTitle("Klubovi");
	}

	
}
