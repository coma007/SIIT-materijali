package kss.gui.igraci;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import kss.managers.IgraciManager;
import kss.managers.KluboviManager;
import kss.model.Igrac;

public class FrmIgraci extends JFrame {

	private static final long serialVersionUID = 8886614103912999395L;
	
	private EditIgracDlg editIgracDlg;
	JButton btnEdit;
	JButton btnDelete;

	public FrmIgraci(IgraciManager im, KluboviManager km) {
		this.editIgracDlg = new EditIgracDlg(this, km);
		
		IgraciModel tim = new IgraciModel(im);
		JTable tblIgraci = new JTable(tim);
		tblIgraci.setAutoCreateRowSorter(true);
		tblIgraci.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (tblIgraci.getSelectedRow() != -1) {
					btnEdit.setEnabled(true);
					btnDelete.setEnabled(true);
				} else {
					btnEdit.setEnabled(false);
					btnDelete.setEnabled(false);
				}
			}
		});
		
		JScrollPane sp = new JScrollPane(tblIgraci);
		
		getContentPane().add(sp, BorderLayout.CENTER);
		
		JPanel pnlButtons = new JPanel();

		JButton btnNew = new JButton("Dodaj novog");
		btnNew.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Igrac i = new Igrac();
				editIgracDlg.setIgrac(i, true);
				editIgracDlg.setVisible(true);
				
				if (!editIgracDlg.isOdustao()) {
					im.getIgraci().add(i);
					tim.fireTableDataChanged();
				}
			}
		});
		pnlButtons.add(btnNew);
		
		btnEdit = new JButton("Izmeni");
		btnEdit.setEnabled(false);
		btnEdit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int idx = tblIgraci.getSelectedRow();
				if (idx != -1) {
					int idxSorted = tblIgraci.convertRowIndexToModel(idx);
					Igrac i = im.getIgraci().get(idxSorted);
					editIgracDlg.setIgrac(i, false);
					editIgracDlg.setVisible(true);
					tim.fireTableDataChanged();
					tblIgraci.setRowSelectionInterval(idx, idx);
				}
			}
		});
		pnlButtons.add(btnEdit);
		
		btnDelete = new JButton("Obriši");
		btnDelete.setEnabled(false);
		btnDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int opt = JOptionPane.showConfirmDialog(null, "Da li ste sigurni da želite da obrišete igrača?",
						"Potvrdite", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				if (opt == JOptionPane.YES_OPTION) {
					int idx = tblIgraci.getSelectedRow();
					if (idx != -1) {
						int idxSorted = tblIgraci.convertRowIndexToModel(idx);
						Igrac i = im.getIgraci().get(idxSorted);
						i.getKlub().getIgraci().remove(i);
						im.getIgraci().remove(i);
						tim.fireTableDataChanged();
					}
				}
			}
		});
		pnlButtons.add(btnDelete);
		
		JButton btnZatvori = new JButton("Zatvori");
		btnZatvori.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		pnlButtons.add(btnZatvori);
		
		getContentPane().add(pnlButtons, BorderLayout.SOUTH);
		
		setSize(800, 600);
		setTitle("Igraci");
		
	}

	
}
