package kss.model;

import java.util.ArrayList;
import java.util.List;

public class Klub {
	private int id;
	private String naziv;
	private List<Igrac> igraci;

	public Klub() {
		this.igraci = new ArrayList<Igrac>();
	}

	public Klub(int id, String naziv) {
		this();
		this.id = id;
		this.naziv = naziv;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public List<Igrac> getIgraci() {
		return igraci;
	}

	public void setIgraci(List<Igrac> igraci) {
		this.igraci = igraci;
	}

	@Override
	public String toString() {
		return "Klub [id=" + id + ", naziv=" + naziv + ", igraci.count=" + igraci.size() + "]";
	}

	public Object toCell(int columnIndex) {
		switch (columnIndex) {
		case 0:
			return "" + this.id;
		case 1:
			return this.naziv;
		}
		return "";
	}

}
