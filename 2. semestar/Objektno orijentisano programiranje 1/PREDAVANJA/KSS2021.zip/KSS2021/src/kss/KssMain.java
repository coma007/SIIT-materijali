package kss;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;

import kss.gui.igraci.FrmIgraci;
import kss.gui.klubovi.FrmKlubovi;
import kss.managers.IgraciManager;
import kss.managers.KluboviManager;

public class KssMain extends JFrame {
	
	private static final long serialVersionUID = -7296402190921762782L;
	private FrmKlubovi frmKlubovi;
	private FrmIgraci frmIgraci;

	public KssMain() {
		KluboviManager km = new KluboviManager("klubovi.txt");
		IgraciManager im = new IgraciManager("igraci.txt", km);

		UIManager.put("OptionPane.yesButtonText", "Da");
		UIManager.put("OptionPane.noButtonText", "Ne");
		UIManager.put("OptionPane.cancelButtonText", "Otkaži");
		UIManager.put("OptionPane.okButtonText", "U redu");
		
		this.frmKlubovi = new FrmKlubovi(km);
		this.frmIgraci = new FrmIgraci(im, km);
		JPanel btnPanel = new JPanel();
		
		
		JButton btnKlubovi = new JButton("Klubovi");
		btnKlubovi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frmKlubovi.setVisible(true);
			}
		});
		btnPanel.add(btnKlubovi);
		
		JButton btnIgraci = new JButton("Igraci");
		btnIgraci.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frmIgraci.setVisible(true);
			}
		});
		btnPanel.add(btnIgraci);
		
		JButton btnZatvori = new JButton("Zatvori");
		btnZatvori.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnPanel.add(btnZatvori);

		getContentPane().add(btnPanel, BorderLayout.NORTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.setSize(800, 600);
		this.setTitle("KSS");
		this.setVisible(true);
	}

	public static void main(String[] args) {
		new KssMain();
	}

}
