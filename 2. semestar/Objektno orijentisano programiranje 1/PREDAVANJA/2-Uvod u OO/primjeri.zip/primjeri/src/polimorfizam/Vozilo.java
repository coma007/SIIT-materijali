package polimorfizam;

public interface Vozilo {
	double platiPutarinu();
}
