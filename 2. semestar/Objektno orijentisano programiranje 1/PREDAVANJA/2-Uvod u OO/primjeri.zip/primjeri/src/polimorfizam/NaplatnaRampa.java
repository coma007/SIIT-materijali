package polimorfizam;

public class NaplatnaRampa {
	public double naplatiPutarinu(Vozilo v) {
		return v.platiPutarinu();
	}
}
