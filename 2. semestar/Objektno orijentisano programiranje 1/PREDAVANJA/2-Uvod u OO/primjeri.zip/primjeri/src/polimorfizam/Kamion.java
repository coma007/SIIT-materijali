package polimorfizam;

public class Kamion implements Vozilo {

	public Kamion(String ime) {
	}

	@Override
	public double platiPutarinu() {
		return 1000;
	}

}
