package nasledjivanje;

import java.io.IOException;

public class Test {

	public static void main(String[] args)  {
		try {
			new Automobil("TEST");
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("DALJE");
	}

}
