package test;

public class Student {
	String ime;
	String prezime;
	
	public Student() {
		
	}

	public Student(String ime, String prezime) {
		this();
		this.ime = ime;
		this.prezime = prezime;
	}
	
	
	
}
