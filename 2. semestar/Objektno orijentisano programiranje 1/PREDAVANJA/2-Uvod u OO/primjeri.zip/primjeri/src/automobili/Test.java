package automobili;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Automobil a = new Automobil();
		a.getPrednjiDesni().pritisak = 6.0;
		
		System.out.println(a.getPrednjiDesni().pritisak);
		
		a.upali();
		
		Automobil.i = 5;
		
		System.out.println(Automobil.BROJ_VRATA);
		Automobil.f();
		
//		
		Automobil b = new Automobil(a);
//		
		System.out.println(b.i);
		b.i++;
		
		System.out.println(a.i);
//		a.prednjiDesni.pritisak = 5.0;
//		
//		System.out.println(a.prednjiDesni.pritisak);
//		
//		System.out.println(b.prednjiDesni.pritisak);
//		
//		Tocak t1 = new Tocak();
//		Tocak t2 = new Tocak();
//		System.out.println(t1);
//		System.out.printf("%x\n", t1.hashCode());
//		System.out.println(t2);
//		System.out.printf("%x\n", t2.hashCode());
//		
//		String s1 = "abc";
//		String s2 = "abc";
//		
//		System.out.println(s1 == s2);
//		System.out.println(s1.equals(s2));
//		
//		s1 = "abc";
//		s2 = new String("abc");
//		
//		System.out.println(s1 == s2);
//		System.out.println(s1.equals(s2));
		
	}

}
