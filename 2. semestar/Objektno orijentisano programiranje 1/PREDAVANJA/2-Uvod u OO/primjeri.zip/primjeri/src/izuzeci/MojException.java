package izuzeci;

public class MojException extends Exception {
	public MojException(String msg) {
		super(msg);
	}
}
